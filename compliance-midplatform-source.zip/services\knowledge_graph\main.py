"""
知识图谱 API — FastAPI 服务入口

启动方式:
    uvicorn services.knowledge_graph.main:app --port 8102 --reload

API:
    POST /api/search       — GraphRAG 检索
    GET  /api/playbook/{id} — Playbook 详情
    POST /api/seed         — 初始化 Schema + 种子数据
    GET  /health           — 健康检查
"""

import sys
import os
import logging

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))

from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel, Field
from typing import Optional

from shared.config import config
from services.knowledge_graph.schema import Neo4jConnection, init_schema
from services.knowledge_graph.seed_data import seed_database
from services.knowledge_graph.graph_rag import GraphRAGEngine, GraphRAGResult

logger = logging.getLogger(__name__)

# ─── 全局状态 ──────────────────────────────────────────────────

conn = Neo4jConnection(
    uri=config.neo4j_uri,
    user=config.neo4j_user,
    password=config.neo4j_password,
)
rag_engine: Optional[GraphRAGEngine] = None


def get_rag_engine() -> GraphRAGEngine:
    global rag_engine
    if rag_engine is None:
        rag_engine = GraphRAGEngine(conn)
    return rag_engine


# ─── FastAPI 应用 ──────────────────────────────────────────────

app = FastAPI(
    title="合规知识图谱 API",
    description="零信任合规审查中台 — Neo4j 知识图谱 + GraphRAG 检索引擎",
    version="1.0.0",
)


class SearchRequest(BaseModel):
    query: str = Field(..., description="检索查询文本", min_length=1)
    domain: Optional[str] = Field(
        default=None,
        description="合规领域: data_privacy | cross_border_transfer | ai_governance | export_control",
    )
    top_k: int = Field(default=5, ge=1, le=20, description="返回结果数量")


class SearchResponse(BaseModel):
    query: str
    domain: Optional[str]
    total_hits: int
    clauses: list[dict]
    playbooks: list[dict]


class PlaybookDetailResponse(BaseModel):
    playbook_id: str
    title: str
    content: str
    domain: str
    redlines: list[dict]
    clauses: list[dict]
    cases: list[dict]


class HealthResponse(BaseModel):
    status: str
    neo4j: dict


@app.on_event("startup")
async def startup():
    if conn.verify_connectivity():
        logger.info("neo4j_connected")
    else:
        logger.warning("neo4j_not_connected — 知识图谱功能将不可用")


@app.on_event("shutdown")
async def shutdown():
    conn.close()


@app.get("/health", response_model=HealthResponse)
async def health():
    engine = get_rag_engine()
    return HealthResponse(status="ok", neo4j=engine.health_check())


@app.post("/api/search", response_model=SearchResponse)
async def search(request: SearchRequest):
    """GraphRAG 检索: 输入查询文本，返回相关条款和 Playbook"""
    engine = get_rag_engine()
    result = engine.search(
        query=request.query,
        domain=request.domain,
        top_k=request.top_k,
    )

    return SearchResponse(
        query=result.query,
        domain=result.domain,
        total_hits=result.total_hits,
        clauses=[
            {
                "clause_id": c.clause_id,
                "title": c.title,
                "content": c.content,
                "regulation": c.regulation,
                "risk_level": c.risk_level,
                "relevance_score": round(c.relevance_score, 4),
            }
            for c in result.clauses
        ],
        playbooks=[
            {
                "playbook_id": p.playbook_id,
                "title": p.title,
                "content": p.content,
                "domain": p.domain,
                "relevance_score": round(p.relevance_score, 4),
                "related_redlines": p.related_redlines,
                "related_cases": p.related_cases,
            }
            for p in result.playbooks
        ],
    )


@app.get("/api/playbook/{playbook_id}", response_model=PlaybookDetailResponse)
async def get_playbook(playbook_id: str):
    """获取 Playbook 完整详情"""
    engine = get_rag_engine()
    detail = engine.get_playbook_detail(playbook_id)
    if not detail:
        raise HTTPException(status_code=404, detail=f"Playbook {playbook_id} 不存在")
    return PlaybookDetailResponse(**detail)


@app.post("/api/seed")
async def seed():
    """初始化 Schema 并写入种子数据（仅开发环境使用）"""
    try:
        init_schema(conn)
        seed_database(conn)
        return {"status": "ok", "message": "Schema 和种子数据已初始化"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"初始化失败: {str(e)}")


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "services.knowledge_graph.main:app",
        host="0.0.0.0",
        port=config.knowledge_graph_port,
        log_level=config.log_level.lower(),
    )
