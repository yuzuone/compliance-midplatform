"""
MCP (Model Context Protocol) 协议定义 — "脑手分离"架构的核心通信层。

架构原则：
  - 合规决策逻辑（脑）与文档渲染引擎（手）通过 MCP 物理隔离
  - 所有跨服务通信必须走 MCP 标准协议，禁止直接 HTTP 调用
  - 传输数据必须经过 PII 脱敏网关处理

MCP 消息生命周期：
  Request → [PII Gateway 脱敏] → Compliance Agent (脑) → [审查建议]
          → MCP Tools/Call → Document Engine (手) → 红线批注 Word
"""

from __future__ import annotations

import json
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional


# ─── MCP 标准消息类型 ───────────────────────────────────────────

class MCPMethod(str, Enum):
    """MCP JSON-RPC 方法名"""
    INITIALIZE = "initialize"
    TOOLS_LIST = "tools/list"
    TOOLS_CALL = "tools/call"
    RESOURCES_LIST = "resources/list"
    RESOURCES_READ = "resources/read"
    PROMPTS_LIST = "prompts/list"
    PROMPTS_GET = "prompts/get"
    NOTIFICATION = "notifications/initialized"


@dataclass
class MCPRequest:
    """标准 MCP JSON-RPC 请求"""
    jsonrpc: str = "2.0"
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    method: str = ""
    params: dict = field(default_factory=dict)

    def to_json(self) -> str:
        return json.dumps({
            "jsonrpc": self.jsonrpc,
            "id": self.id,
            "method": self.method,
            "params": self.params,
        }, ensure_ascii=False)

    @classmethod
    def from_json(cls, raw: str | bytes) -> "MCPRequest":
        if isinstance(raw, bytes):
            raw = raw.decode("utf-8")
        data = json.loads(raw)
        return cls(
            id=data.get("id", str(uuid.uuid4())),
            method=data.get("method", ""),
            params=data.get("params", {}),
        )


@dataclass
class MCPResponse:
    """标准 MCP JSON-RPC 响应"""
    jsonrpc: str = "2.0"
    id: str = ""
    result: Any = None
    error: Optional[dict] = None

    def to_json(self) -> str:
        payload = {"jsonrpc": self.jsonrpc, "id": self.id}
        if self.error:
            payload["error"] = self.error
        else:
            payload["result"] = self.result
        return json.dumps(payload, ensure_ascii=False)

    @classmethod
    def error_response(cls, req_id: str, code: int, message: str) -> "MCPResponse":
        return cls(id=req_id, error={"code": code, "message": message})


# ─── 领域消息类型（合规审查专用） ─────────────────────────────────

class ReviewSeverity(str, Enum):
    """审查意见严重程度"""
    CRITICAL = "critical"   # 红线条款违规
    HIGH = "high"           # 高风险
    MEDIUM = "medium"       # 中风险
    LOW = "low"             # 低风险
    INFO = "info"           # 提示


class AnnotationType(str, Enum):
    """Word 批注类型（对应文档渲染引擎操作）"""
    DELETE = "delete"       # 删除标记（红线删除）
    INSERT = "insert"       # 插入标记（蓝线新增）
    REPLACE = "replace"     # 替换（删除+插入）
    COMMENT = "comment"     # 批注（不修改正文）
    HIGHLIGHT = "highlight" # 高亮标记


@dataclass
class PIIEntity:
    """PII 实体识别结果"""
    entity_type: str        # 实体类型: PERSON, PHONE, EMAIL, ID_CARD, ADDRESS, COMPANY
    original_text: str      # 原始文本
    masked_text: str        # 脱敏后的文本
    start_pos: int          # 在原文档中的起始位置
    end_pos: int            # 在原文档中的结束位置
    confidence: float       # 识别置信度 0-1


@dataclass
class ComplianceReviewResult:
    """合规审查结果（合规决策智能体输出）"""
    review_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    document_id: str = ""
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    # 审查发现
    findings: list[ComplianceFinding] = field(default_factory=list)

    # 脱敏后的摘要（可安全传入云端 LLM）
    desensitized_summary: str = ""

    # 关联的知识图谱节点 ID
    related_playbook_ids: list[str] = field(default_factory=list)


@dataclass
class ComplianceFinding:
    """单条合规发现"""
    finding_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    severity: ReviewSeverity = ReviewSeverity.INFO

    # 原文引用（脱敏后）
    original_context: str = ""
    # 违规描述
    description: str = ""
    # 关联的红线条款
    playbook_clause: str = ""
    # 建议修改方向
    suggested_fix: str = ""

    # 文档渲染指令
    annotations: list[DocumentAnnotation] = field(default_factory=list)


@dataclass
class DocumentAnnotation:
    """文档红线批注指令 — 发给文档渲染引擎的参数"""
    annotation_type: AnnotationType
    # 在文档中的定位信息
    paragraph_index: int = 0
    start_char: int = 0
    end_char: int = 0
    # 要删除/替换/插入的文本
    original_text: str = ""
    suggested_text: str = ""
    # 批注/高亮用
    comment_text: str = ""
    highlight_color: str = "FF0000"  # 默认红色


# ─── MCP Tool 定义（注册给 Dify/Dify 平台） ──────────────────────

MCP_TOOLS = [
    {
        "name": "compliance_review",
        "description": "对脱敏后的文档内容进行合规审查，返回审查建议与红线批注指令",
        "inputSchema": {
            "type": "object",
            "properties": {
                "document_id": {"type": "string", "description": "文档唯一标识"},
                "desensitized_content": {"type": "string", "description": "已脱敏的文档正文"},
                "compliance_domain": {
                    "type": "string",
                    "description": "合规领域: data_privacy | export_control | labor_law | anti_bribery",
                },
            },
            "required": ["document_id", "desensitized_content"],
        },
    },
    {
        "name": "render_redline_document",
        "description": "根据审查建议生成带红线批注的 Word 文档",
        "inputSchema": {
            "type": "object",
            "properties": {
                "template_path": {"type": "string", "description": "原始文档模板路径"},
                "annotations": {
                    "type": "array",
                    "items": {"$ref": "#/components/schemas/DocumentAnnotation"},
                },
                "output_path": {"type": "string", "description": "输出文件路径"},
            },
            "required": ["template_path", "annotations"],
        },
    },
    {
        "name": "query_playbook",
        "description": "从 Neo4j 知识图谱检索相关红线条款",
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "检索查询文本"},
                "domain": {"type": "string", "description": "合规领域过滤"},
                "top_k": {"type": "integer", "default": 5},
            },
            "required": ["query"],
        },
    },
    {
        "name": "desensitize_document",
        "description": "对文档内容进行 PII 实体识别与脱敏处理",
        "inputSchema": {
            "type": "object",
            "properties": {
                "content": {"type": "string", "description": "原始文档内容"},
                "strategy": {
                    "type": "string",
                    "enum": ["mask", "replace", "redact"],
                    "default": "mask",
                },
                "entity_types": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "要识别的实体类型，默认全部",
                },
            },
            "required": ["content"],
        },
    },
]
