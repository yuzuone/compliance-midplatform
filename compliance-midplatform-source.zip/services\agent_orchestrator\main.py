"""
Agent 编排引擎 API — 中台核心服务

启动: uvicorn services.agent_orchestrator.main:app --port 8100 --reload

API:
  POST /api/agents/register     — Agent 注册
  POST /api/agents/{id}/heartbeat — 心跳上报
  GET  /api/agents               — 列出所有 Agent
  GET  /api/agents/status        — 注册中心状态

  POST /api/tasks/review         — 创建合规审查任务
  GET  /api/tasks/{id}           — 查询任务状态
  GET  /api/tasks/active         — 当前活跃任务
  GET  /api/tasks/history        — 历史任务

  POST /api/pipelines            — 注册流水线
  GET  /api/pipelines            — 列出流水线

  GET  /health                   — 健康检查
"""

import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))

import logging

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger(__name__)

from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import Optional

from services.agent_orchestrator.models import (
    AgentRegistration,
    AgentStatus,
    AgentType,
    AgentCapability,
    OrchestrationTask,
    TaskStatus,
    TaskPriority,
    PipelineDefinition,
    DEFAULT_PIPELINE,
    QUICK_REVIEW_PIPELINE,
    PII_ONLY_PIPELINE,
)
from services.agent_orchestrator.agent_registry import agent_registry
from services.agent_orchestrator.task_router import TaskRouter

# ─── 全局 ──────────────────────────────────────────────────────

task_router = TaskRouter(agent_registry)

# 注册预定义流水线
PREDEFINED_PIPELINES = {
    "compliance_review": DEFAULT_PIPELINE,
    "quick_review": QUICK_REVIEW_PIPELINE,
    "pii_scan": PII_ONLY_PIPELINE,
}

# ─── FastAPI ───────────────────────────────────────────────────

app = FastAPI(
    title="Agent 编排引擎",
    description="零信任合规审查中台 — 多智能体编排与任务调度",
    version="2.0.0",
)

app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


# ─── Pydantic 模型 ────────────────────────────────────────────

class AgentRegisterRequest(BaseModel):
    agent_type: str
    name: str
    version: str = "1.0.0"
    endpoint: str
    capabilities: list[dict] = []

class ReviewRequest(BaseModel):
    tenant_id: str = "default"
    document_content: str = Field(..., min_length=1)
    compliance_domain: str = "data_privacy"
    pipeline_name: str = "compliance_review"
    priority: str = "medium"

class PipelineRequest(BaseModel):
    name: str
    display_name: str
    description: str
    steps: list[dict]


# ─── Agent 管理 ────────────────────────────────────────────────

@app.post("/api/agents/register")
async def register_agent(req: AgentRegisterRequest):
    """注册一个 Agent 到中台"""
    capabilities = [
        AgentCapability(**cap) for cap in req.capabilities
    ]
    agent = AgentRegistration(
        agent_type=AgentType(req.agent_type),
        name=req.name,
        version=req.version,
        endpoint=req.endpoint,
        capabilities=capabilities,
    )
    agent_id = agent_registry.register(agent)
    return {"status": "ok", "agent_id": agent_id}


@app.post("/api/agents/{agent_id}/heartbeat")
async def agent_heartbeat(agent_id: str):
    """Agent 心跳上报"""
    ok = agent_registry.heartbeat(agent_id)
    if not ok:
        raise HTTPException(404, "Agent 不存在")
    return {"status": "ok"}


@app.get("/api/agents")
async def list_agents():
    """列出所有已注册 Agent"""
    agents = agent_registry.list_all()
    return {
        "total": len(agents),
        "agents": [
            {
                "agent_id": a.agent_id,
                "type": a.agent_type.value,
                "name": a.name,
                "version": a.version,
                "status": a.status.value,
                "capabilities": [c.name for c in a.capabilities],
                "last_heartbeat": a.last_heartbeat,
            }
            for a in agents
        ],
    }


@app.get("/api/agents/status")
async def agent_status():
    """获取注册中心整体状态"""
    return agent_registry.get_registry_status()


# ─── 任务管理 ──────────────────────────────────────────────────

@app.post("/api/tasks/review")
async def create_review_task(req: ReviewRequest, background: BackgroundTasks):
    """创建并执行合规审查任务"""
    pipeline = PREDEFINED_PIPELINES.get(req.pipeline_name)
    if not pipeline:
        raise HTTPException(400, f"未知流水线: {req.pipeline_name}")

    task = task_router.create_task(
        tenant_id=req.tenant_id,
        document_content=req.document_content,
        compliance_domain=req.compliance_domain,
        pipeline=pipeline,
        priority=TaskPriority(req.priority),
    )

    # 后台异步执行
    background.add_task(task_router.execute_task, task.task_id)

    return {
        "status": "accepted",
        "task_id": task.task_id,
        "pipeline": req.pipeline_name,
        "steps": len(task.steps),
    }


@app.get("/api/tasks/{task_id}")
async def get_task(task_id: str):
    """查询任务状态和结果"""
    task = task_router.get_task(task_id)
    if not task:
        raise HTTPException(404, "任务不存在")

    return {
        "task_id": task.task_id,
        "tenant_id": task.tenant_id,
        "pipeline": task.pipeline_name,
        "status": task.status.value,
        "priority": task.priority.value,
        "created_at": task.created_at,
        "current_step": task.current_step_index,
        "steps": [
            {
                "step_id": s.step_id,
                "agent_type": s.agent_type.value,
                "capability": s.capability,
                "status": s.status.value,
                "error": s.error,
                "started_at": s.started_at,
                "completed_at": s.completed_at,
            }
            for s in task.steps
        ],
        "context": {
            k: v
            for k, v in task.context.items()
            if k not in ("document_content",)  # 不返回原始文档
        },
    }


@app.get("/api/tasks/active")
async def active_tasks(tenant_id: Optional[str] = None):
    """当前活跃任务"""
    tasks = task_router.list_active_tasks(tenant_id)
    return {
        "total": len(tasks),
        "tasks": [
            {"task_id": t.task_id, "pipeline": t.pipeline_name, "status": t.status.value, "tenant": t.tenant_id}
            for t in tasks
        ],
    }


@app.get("/api/tasks/history")
async def task_history(tenant_id: Optional[str] = None, limit: int = 20):
    """历史任务"""
    tasks = task_router.get_task_history(tenant_id, limit)
    return {
        "total": len(tasks),
        "tasks": [
            {
                "task_id": t.task_id,
                "pipeline": t.pipeline_name,
                "status": t.status.value,
                "tenant": t.tenant_id,
                "created_at": t.created_at,
                "findings": len(t.context.get("compliance_judge", {}).get("findings", [])),
            }
            for t in tasks
        ],
    }


# ─── 流水线管理 ───────────────────────────────────────────────

@app.get("/api/pipelines")
async def list_pipelines():
    """列出所有可用流水线"""
    return {
        "pipelines": [
            {
                "name": p.name,
                "display_name": p.display_name,
                "description": p.description,
                "steps": len(p.steps),
                "enabled": p.enabled,
            }
            for p in PREDEFINED_PIPELINES.values()
        ],
    }


@app.post("/api/pipelines")
async def register_pipeline(req: PipelineRequest):
    """注册自定义流水线"""
    pipeline = PipelineDefinition(
        name=req.name,
        display_name=req.display_name,
        description=req.description,
        steps=req.steps,
    )
    PREDEFINED_PIPELINES[req.name] = pipeline
    return {"status": "ok", "name": req.name}


# ─── 健康检查 ──────────────────────────────────────────────────

@app.get("/health")
async def health():
    return {
        "status": "ok",
        "service": "agent-orchestrator",
        "version": "2.0.0",
        "registry": agent_registry.get_registry_status(),
    }


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8100, log_level="info")
