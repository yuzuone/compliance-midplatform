"""
GraphRAG 检索引擎 — 基于 Neo4j 知识图谱的精准合规条款检索。

检索策略（三层）:
  Layer 1: 关键词全文索引 → 找到直接相关的条款
  Layer 2: 图遍历 → 从条款追踪到红线条款和 Playbook
  Layer 3: 案例相似性 → 查找类似审查案例的判决结果
"""

import logging
from dataclasses import dataclass, field
from typing import Optional

from services.knowledge_graph.schema import Neo4jConnection

logger = logging.getLogger(__name__)


@dataclass
class PlaybookHit:
    """Playbook 检索命中"""
    playbook_id: str
    title: str
    content: str
    domain: str
    relevance_score: float
    related_redlines: list[dict] = field(default_factory=list)
    related_cases: list[dict] = field(default_factory=list)


@dataclass
class ClauseHit:
    """条款检索命中"""
    clause_id: str
    title: str
    content: str
    regulation: str
    risk_level: str
    relevance_score: float


@dataclass
class GraphRAGResult:
    """GraphRAG 检索结果"""
    query: str
    domain: Optional[str]
    clauses: list[ClauseHit]
    playbooks: list[PlaybookHit]
    total_hits: int


class GraphRAGEngine:
    """
    GraphRAG 检索引擎。

    使用方式:
        conn = Neo4jConnection(uri, user, password)
        engine = GraphRAGEngine(conn)
        result = engine.search("跨境数据传输合规要求", domain="cross_border_transfer")
        for pb in result.playbooks:
            print(pb.title, pb.content)
    """

    def __init__(self, conn: Neo4jConnection):
        self.conn = conn

    def search(
        self,
        query: str,
        domain: Optional[str] = None,
        top_k: int = 5,
    ) -> GraphRAGResult:
        """
        执行 GraphRAG 查询 — 三层检索策略。

        Args:
            query: 检索查询文本
            domain: 可选，限制合规领域
            top_k: 返回结果数量

        Returns:
            GraphRAGResult 包含条款和 Playbook 命中
        """
        # Layer 1: 全文检索条款
        clauses = self._search_clauses(query, domain, top_k)

        # Layer 2: 图遍历 → Playbook + 红线
        playbooks = self._traverse_to_playbooks(clauses, top_k)

        # Layer 3: 案例追溯
        for pb in playbooks:
            pb.related_cases = self._find_related_cases(pb.playbook_id)

        return GraphRAGResult(
            query=query,
            domain=domain,
            clauses=clauses,
            playbooks=playbooks,
            total_hits=len(clauses) + len(playbooks),
        )

    # ─── Layer 1: 全文检索条款 ──────────────────────────────────

    def _search_clauses(
        self, query: str, domain: Optional[str], top_k: int
    ) -> list[ClauseHit]:
        """使用 Neo4j 全文索引检索条款"""
        domain_filter = ""
        domain_params = {}

        if domain:
            domain_filter = """
            MATCH (d:ComplianceDomain {name: $domain})
            MATCH (rl:RedLine)-[:BELONGS_TO]->(d)
            MATCH (c:Clause)-[:VIOLATES]->(rl)
            """
            domain_params["domain"] = domain

        cypher = f"""
        CALL db.index.fulltext.queryNodes('clause_text_index', $query) YIELD node AS c, score
        {domain_filter if not domain else ''}
        OPTIONAL MATCH (r:Regulation)-[:CONTAINS]->(c)
        RETURN c.clause_id AS clause_id,
               c.title AS title,
               c.content AS content,
               c.risk_level AS risk_level,
               score,
               collect(DISTINCT r.name) AS regulations
        ORDER BY score DESC
        LIMIT $top_k
        """

        if domain:
            # 有领域过滤时用更复杂的查询
            cypher = f"""
            CALL db.index.fulltext.queryNodes('clause_text_index', $query) YIELD node AS c, score
            MATCH (c)-[:VIOLATES]->(rl:RedLine)-[:BELONGS_TO]->(d:ComplianceDomain {{name: $domain}})
            OPTIONAL MATCH (r:Regulation)-[:CONTAINS]->(c)
            RETURN c.clause_id AS clause_id,
                   c.title AS title,
                   c.content AS content,
                   c.risk_level AS risk_level,
                   score,
                   collect(DISTINCT r.name) AS regulations
            ORDER BY score DESC
            LIMIT $top_k
            """

        params = {"query": query, "top_k": top_k, **domain_params}

        with self.conn.session() as session:
            result = session.run(cypher, params)
            hits = []
            for record in result:
                regulations = record.get("regulations", [])
                hits.append(
                    ClauseHit(
                        clause_id=record["clause_id"],
                        title=record["title"],
                        content=record["content"],
                        regulation=regulations[0] if regulations else "Unknown",
                        risk_level=record.get("risk_level", "medium"),
                        relevance_score=record["score"],
                    )
                )
            return hits

    # ─── Layer 2: 图遍历 → Playbook ─────────────────────────────

    def _traverse_to_playbooks(
        self, clauses: list[ClauseHit], top_k: int
    ) -> list[PlaybookHit]:
        """从检索到的条款出发，遍历图找到关联的 Playbook"""
        if not clauses:
            return []

        clause_ids = [c.clause_id for c in clauses]

        cypher = """
        UNWIND $clause_ids AS cid
        MATCH (c:Clause {clause_id: cid})
        MATCH (c)-[:VIOLATES]->(rl:RedLine)
        MATCH (pb:Playbook)-[:REFERENCED_BY]->(rl)
        MATCH (d:ComplianceDomain)-[:BELONGS_TO]-(rl)
        RETURN DISTINCT
               pb.playbook_id AS playbook_id,
               pb.title AS title,
               pb.content AS content,
               pb.domain AS domain,
               count(DISTINCT rl) AS redline_count,
               collect(DISTINCT {redline_id: rl.redline_id, title: rl.title, priority: rl.priority}) AS redlines,
               collect(DISTINCT d.name) AS domains
        ORDER BY redline_count DESC
        LIMIT $top_k
        """

        with self.conn.session() as session:
            result = session.run(cypher, {"clause_ids": clause_ids, "top_k": top_k})
            hits = []
            for record in result:
                hits.append(
                    PlaybookHit(
                        playbook_id=record["playbook_id"],
                        title=record["title"],
                        content=record["content"],
                        domain=record["domain"],
                        relevance_score=record["redline_count"] / max(len(clause_ids), 1),
                        related_redlines=record["redlines"],
                    )
                )
            return hits

    # ─── Layer 3: 案例追溯 ──────────────────────────────────────

    def _find_related_cases(self, playbook_id: str) -> list[dict]:
        """查找与 Playbook 关联的历史审查案例"""
        cypher = """
        MATCH (pb:Playbook {playbook_id: $playbook_id})
        MATCH (pb)-[:REFERENCED_BY]->(rl:RedLine)
        MATCH (cse:ReviewCase)-[:FOUND_VIOLATION]->(rl)
        RETURN cse.case_id AS case_id,
               cse.title AS title,
               cse.summary AS summary,
               cse.outcome AS outcome,
               cse.severity AS severity
        """

        with self.conn.session() as session:
            result = session.run(cypher, {"playbook_id": playbook_id})
            return [
                {
                    "case_id": record["case_id"],
                    "title": record["title"],
                    "summary": record["summary"],
                    "outcome": record["outcome"],
                    "severity": record["severity"],
                }
                for record in result
            ]

    # ─── 辅助: 获取完整 Playbook 详情 ────────────────────────────

    def get_playbook_detail(self, playbook_id: str) -> Optional[dict]:
        """获取 Playbook 完整信息（含所有关联条款、红线和案例）"""
        cypher = """
        MATCH (pb:Playbook {playbook_id: $playbook_id})
        OPTIONAL MATCH (pb)-[:REFERENCED_BY]->(rl:RedLine)
        OPTIONAL MATCH (rl)<-[:VIOLATES]-(c:Clause)
        OPTIONAL MATCH (rl)<-[:FOUND_VIOLATION]-(cse:ReviewCase)
        OPTIONAL MATCH (c)<-[:CONTAINS]-(r:Regulation)
        RETURN pb.playbook_id AS playbook_id,
               pb.title AS title,
               pb.content AS content,
               pb.domain AS domain,
               collect(DISTINCT {
                   redline_id: rl.redline_id,
                   title: rl.title,
                   description: rl.description,
                   remediation: rl.remediation,
                   priority: rl.priority
               }) AS redlines,
               collect(DISTINCT {
                   clause_id: c.clause_id,
                   title: c.title,
                   regulation: r.name
               }) AS clauses,
               collect(DISTINCT {
                   case_id: cse.case_id,
                   title: cse.title
               }) AS cases
        """

        with self.conn.session() as session:
            record = session.run(cypher, {"playbook_id": playbook_id}).single()
            if not record:
                return None
            return dict(record)

    def health_check(self) -> dict:
        """检查 Neo4j 连接和图数据状态"""
        try:
            with self.conn.session() as session:
                result = session.run(
                    "MATCH (n) RETURN DISTINCT labels(n) AS label, count(n) AS cnt"
                )
                counts = {r["label"][0]: r["cnt"] for r in result}
                return {"status": "healthy", "node_counts": counts}
        except Exception as e:
            return {"status": "unhealthy", "error": str(e)}
