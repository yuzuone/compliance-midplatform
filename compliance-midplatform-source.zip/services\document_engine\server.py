"""
MCP 文档渲染引擎 Server — "脑手分离"架构中的"手"。

本服务通过 MCP 协议暴露文档渲染工具，接收来自合规决策智能体的
结构化审查指令（DocumentAnnotation[]），不接触原始数据和 LLM 自由文本。

MCP 传输模式:
  - stdio: 标准输入输出（用于 Dify 平台等工具调用）
  - HTTP+SSE: HTTP 服务器 + Server-Sent Events（用于 REST 客户端）

启动方式:
  # stdio 模式（默认，用于 Dify MCP 集成）
  python services/document_engine/server.py

  # HTTP 模式（用于 REST API 调试）
  python services/document_engine/server.py --transport http --port 8103
"""

import sys
import os
import json
import logging
import asyncio
import argparse
from datetime import datetime
from typing import Optional

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))

from shared.config import config
from shared.mcp_protocol import (
    MCPRequest,
    MCPResponse,
    MCPMethod,
    MCP_TOOLS,
    DocumentAnnotation,
    AnnotationType,
)
from services.document_engine.word_renderer import (
    WordRedlineEngine,
    AnnotationInstruction,
)

logger = logging.getLogger(__name__)


# ─── MCP Server 核心逻辑 ───────────────────────────────────────

class DocumentEngineMCPServer:
    """
    文档渲染引擎 MCP Server。

    暴露的工具:
      - render_redline_document: 接收审查批注指令，生成带红线的 Word 文档
      - health_check: 健康检查（自定义工具）
    """

    def __init__(self, work_dir: str = "./output"):
        self.renderer = WordRedlineEngine()
        self.work_dir = os.path.abspath(work_dir)
        os.makedirs(self.work_dir, exist_ok=True)

        # 工具处理器映射
        self._tool_handlers = {
            "render_redline_document": self._handle_render_redline,
            "health_check": self._handle_health_check,
        }

    async def handle_request(self, raw: str) -> str:
        """
        处理 MCP JSON-RPC 请求。

        Args:
            raw: JSON-RPC 请求字符串

        Returns:
            JSON-RPC 响应字符串
        """
        try:
            request = MCPRequest.from_json(raw)
        except (json.JSONDecodeError, KeyError) as e:
            return MCPResponse.error_response("", -32700, f"解析错误: {str(e)}").to_json()

        logger.info("mcp_request", method=request.method, id=request.id)

        try:
            if request.method == MCPMethod.INITIALIZE:
                result = await self._handle_initialize(request.params)
            elif request.method == MCPMethod.TOOLS_LIST:
                result = await self._handle_tools_list()
            elif request.method == MCPMethod.TOOLS_CALL:
                result = await self._handle_tools_call(request.params)
            elif request.method == MCPMethod.RESOURCES_LIST:
                result = {"resources": []}
            else:
                return MCPResponse.error_response(
                    request.id, -32601, f"方法未实现: {request.method}"
                ).to_json()

            return MCPResponse(id=request.id, result=result).to_json()

        except Exception as e:
            logger.error("mcp_handler_error", method=request.method, error=str(e))
            return MCPResponse.error_response(
                request.id, -32603, f"内部错误: {str(e)}"
            ).to_json()

    # ─── MCP 方法处理器 ────────────────────────────────────

    async def _handle_initialize(self, params: dict) -> dict:
        """MCP initialize 握手"""
        return {
            "protocolVersion": "2024-11-05",
            "capabilities": {
                "tools": {},
                "resources": {},
            },
            "serverInfo": {
                "name": "zero-trust-compliance-document-engine",
                "version": "1.0.0",
            },
        }

    async def _handle_tools_list(self) -> dict:
        """返回可用工具列表"""
        return {"tools": MCP_TOOLS}

    async def _handle_tools_call(self, params: dict) -> dict:
        """执行工具调用"""
        tool_name = params.get("name", "")
        arguments = params.get("arguments", {})

        handler = self._tool_handlers.get(tool_name)
        if not handler:
            return {
                "content": [{"type": "text", "text": f"未知工具: {tool_name}"}],
                "isError": True,
            }

        try:
            result = await handler(arguments)
            return {
                "content": [{"type": "text", "text": json.dumps(result, ensure_ascii=False)}],
            }
        except Exception as e:
            logger.error("tool_call_error", tool=tool_name, error=str(e))
            return {
                "content": [{"type": "text", "text": f"工具执行失败: {str(e)}"}],
                "isError": True,
            }

    # ─── 工具: render_redline_document ──────────────────────

    async def _handle_render_redline(self, arguments: dict) -> dict:
        """
        接收审查批注指令，生成带红线的 Word 文档。

        参数:
          template_path: 原始文档路径
          annotations: 批注指令列表（DocumentAnnotation 格式）
          output_path: 输出路径（可选）

        返回:
          {"status": "ok", "output_path": "...", "annotation_count": N}
        """
        template_path = arguments.get("template_path", "")
        raw_annotations = arguments.get("annotations", [])
        output_path = arguments.get("output_path")

        if not template_path:
            raise ValueError("缺少 template_path 参数")
        if not raw_annotations:
            raise ValueError("缺少 annotations 参数")

        # 转换 DocumentAnnotation → AnnotationInstruction
        instructions = []
        for ann in raw_annotations:
            instructions.append(
                AnnotationInstruction(
                    annotation_type=ann.get("annotation_type", "comment"),
                    original_text=ann.get("original_text", ""),
                    suggested_text=ann.get("suggested_text", ""),
                    comment_text=ann.get("comment_text", ""),
                    highlight_color=ann.get("highlight_color", "FF0000"),
                    severity=ann.get("severity", "info"),
                    playbook_ref=ann.get("playbook_ref", ""),
                )
            )

        # 渲染文档
        if output_path:
            output_path = os.path.join(self.work_dir, os.path.basename(output_path))

        result_path = self.renderer.render(
            template_path=template_path,
            instructions=instructions,
            output_path=output_path,
        )

        return {
            "status": "ok",
            "output_path": result_path,
            "annotation_count": len(instructions),
            "timestamp": datetime.now().isoformat(),
        }

    # ─── 工具: health_check ────────────────────────────────

    async def _handle_health_check(self, arguments: dict) -> dict:
        """自定义健康检查"""
        return {
            "status": "ok",
            "service": "document-engine",
            "version": "1.0.0",
            "work_dir": self.work_dir,
        }


# ─── stdio Transport ──────────────────────────────────────────

async def run_stdio_server():
    """通过标准输入输出运行 MCP Server（用于 Dify 平台集成）"""
    server = DocumentEngineMCPServer()
    logger.info("mcp_server_starting", transport="stdio")

    # 读取 stdin（asyncio）
    loop = asyncio.get_event_loop()
    reader = asyncio.StreamReader()
    protocol = asyncio.StreamReaderProtocol(reader)
    await loop.connect_read_pipe(lambda: protocol, sys.stdin)

    while True:
        try:
            line = await reader.readline()
            if not line:
                break

            raw = line.decode("utf-8").strip()
            if not raw:
                continue

            response = await server.handle_request(raw)
            # 输出到 stdout
            sys.stdout.write(response + "\n")
            sys.stdout.flush()

        except (EOFError, KeyboardInterrupt):
            break
        except Exception as e:
            logger.error("stdio_read_error", error=str(e))
            break


# ─── HTTP Transport ──────────────────────────────────────────

def run_http_server(port: int = 8103):
    """通过 HTTP 运行 MCP Server（用于 REST API 调用和调试）"""
    from fastapi import FastAPI, Request
    from fastapi.responses import JSONResponse
    import uvicorn

    server = DocumentEngineMCPServer()

    app = FastAPI(
        title="MCP 文档渲染引擎",
        description="零信任合规审查中台 — Word 文档红线批注引擎（MCP Server）",
        version="1.0.0",
    )

    @app.post("/mcp")
    async def mcp_endpoint(request: Request):
        """MCP JSON-RPC 端点"""
        body = await request.json()
        raw = json.dumps(body)
        response_raw = await server.handle_request(raw)
        return JSONResponse(content=json.loads(response_raw))

    @app.post("/api/render")
    async def render_endpoint(request: Request):
        """直接调用渲染（简化的 REST API，非 MCP 标准）"""
        body = await request.json()
        result = await server._handle_render_redline(body)
        return JSONResponse(content=result)

    @app.get("/health")
    async def health_endpoint():
        return {"status": "ok", "service": "document-engine", "version": "1.0.0"}

    logger.info("mcp_server_starting", transport="http", port=port)
    uvicorn.run(app, host="0.0.0.0", port=port, log_level="info")


# ─── 入口 ─────────────────────────────────────────────────────

if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    parser = argparse.ArgumentParser(description="MCP 文档渲染引擎")
    parser.add_argument(
        "--transport",
        choices=["stdio", "http"],
        default="stdio",
        help="传输模式: stdio (Dify MCP 集成) 或 http (REST 调试)",
    )
    parser.add_argument("--port", type=int, default=8103, help="HTTP 模式端口")
    args = parser.parse_args()

    if args.transport == "http":
        run_http_server(port=args.port)
    else:
        asyncio.run(run_stdio_server())
