"""
统一 API 网关 — 中台对外唯一入口。

职责:
  1. 认证 (JWT Bearer Token)
  2. 授权 (RBAC: admin / reviewer / viewer)
  3. 租户隔离 (tenant_id 注入)
  4. 限流 (per-tenant rate limiting)
  5. 请求链路追踪 (X-Request-ID)
  6. 审计日志 (所有 API 调用)
  7. 路由代理 (→ Agent 编排引擎 / 知识库 / PII 网关)

启动:
  python services/api_gateway/main.py
  uvicorn services.api_gateway.main:app --port 8080 --reload
"""

import sys
import os
import time
import uuid
import hashlib
import logging
import json
from datetime import datetime, timezone
from collections import defaultdict
from typing import Optional

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))

from fastapi import FastAPI, Request, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel, Field

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] gateway: %(message)s")
logger = logging.getLogger("api_gateway")

# ─── 租户管理 ──────────────────────────────────────────────────

class TenantManager:
    """简易租户管理（生产环境应替换为数据库）"""

    def __init__(self):
        self._tenants: dict[str, dict] = {}
        self._api_keys: dict[str, str] = {}  # api_key_hash → tenant_id

    def create_tenant(self, tenant_id: str, name: str, role: str = "viewer") -> dict:
        api_key = f"ct_{tenant_id}_{uuid.uuid4().hex[:16]}"
        key_hash = hashlib.sha256(api_key.encode()).hexdigest()

        tenant = {
            "tenant_id": tenant_id,
            "name": name,
            "role": role,
            "api_key_hash": key_hash,
            "rate_limit": 100,
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        self._tenants[tenant_id] = tenant
        self._api_keys[key_hash] = tenant_id

        logger.info("tenant_created tenant=%s role=%s", tenant_id, role)
        return {"tenant_id": tenant_id, "api_key": api_key, "role": role}

    def authenticate(self, api_key: str) -> Optional[dict]:
        key_hash = hashlib.sha256(api_key.encode()).hexdigest()
        tenant_id = self._api_keys.get(key_hash)
        if tenant_id:
            return self._tenants.get(tenant_id)
        return None

    def get_tenant(self, tenant_id: str) -> Optional[dict]:
        return self._tenants.get(tenant_id)


tenant_manager = TenantManager()

# 创建演示租户
demo_tenant = tenant_manager.create_tenant("demo", "演示企业", "reviewer")
logger.info("=" * 60)
logger.info("  API Gateway 演示租户已创建")
logger.info("  Tenant ID: demo")
logger.info("  API Key:   %s", demo_tenant["api_key"])
logger.info("  Role:      reviewer")
logger.info("=" * 60)


# ─── 限流 ──────────────────────────────────────────────────────

class RateLimiter:
    """基于滑动窗口的简易限流器"""

    def __init__(self):
        self._windows: dict[str, list[float]] = defaultdict(list)

    def check(self, key: str, limit: int = 100) -> bool:
        now = time.time()
        window = self._windows[key]
        # 清理过期记录
        self._windows[key] = [t for t in window if now - t < 60]
        if len(self._windows[key]) >= limit:
            return False
        self._windows[key].append(now)
        return True


rate_limiter = RateLimiter()

# ─── FastAPI ───────────────────────────────────────────────────

app = FastAPI(
    title="零信任合规审查中台 — API Gateway",
    description="统一 API 网关: 认证/授权/限流/审计/路由",
    version="2.0.0",
)

app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

security = HTTPBearer(auto_error=False)


# ─── 中间件: Request ID + 审计日志 ────────────────────────────

@app.middleware("http")
async def gateway_middleware(request: Request, call_next):
    # 注入 X-Request-ID
    request_id = request.headers.get("X-Request-ID", str(uuid.uuid4()))
    request.state.request_id = request_id
    request.state.start_time = time.time()

    response = await call_next(request)

    # 审计日志
    duration_ms = int((time.time() - request.state.start_time) * 1000)
    tenant_id = getattr(request.state, "tenant_id", "anonymous")
    logger.info(
        "audit request_id=%s tenant=%s method=%s path=%s status=%d duration_ms=%d",
        request_id, tenant_id, request.method, request.url.path, response.status_code, duration_ms,
    )
    response.headers["X-Request-ID"] = request_id
    return response


# ─── 认证依赖 ──────────────────────────────────────────────────

async def get_tenant(
    request: Request,
    credentials: HTTPAuthorizationCredentials = Depends(security),
):
    """从 Bearer Token 中提取租户信息"""
    # 开发模式：允许无认证访问
    api_key = request.headers.get("X-API-Key", "")
    if api_key:
        tenant = tenant_manager.authenticate(api_key)
        if not tenant:
            raise HTTPException(401, "Invalid API Key")
    elif credentials:
        tenant = tenant_manager.authenticate(credentials.credentials)
        if not tenant:
            raise HTTPException(401, "Invalid Bearer Token")
    else:
        # 开发模式 fallback
        tenant = {"tenant_id": "demo", "name": "演示企业", "role": "reviewer"}

    # 限流检查
    if not rate_limiter.check(tenant["tenant_id"], tenant.get("rate_limit", 100)):
        raise HTTPException(429, "请求过于频繁，请稍后重试")

    request.state.tenant_id = tenant["tenant_id"]
    request.state.tenant_role = tenant["role"]
    return tenant


# ─── API 端点 ──────────────────────────────────────────────────

class TenantCreateRequest(BaseModel):
    name: str = Field(..., min_length=1)
    role: str = "viewer"


class ReviewRequest(BaseModel):
    document_content: str = Field(..., min_length=1)
    compliance_domain: str = "data_privacy"
    pipeline: str = "compliance_review"


@app.post("/api/tenants")
async def create_tenant(req: TenantCreateRequest):
    """创建新租户（管理员操作）"""
    tenant_id = f"tenant_{uuid.uuid4().hex[:8]}"
    result = tenant_manager.create_tenant(tenant_id, req.name, req.role)
    return {"status": "ok", **result}


@app.get("/api/tenants/me")
async def get_current_tenant(tenant: dict = Depends(get_tenant)):
    """获取当前租户信息"""
    return {"tenant_id": tenant["tenant_id"], "name": tenant["name"], "role": tenant["role"]}


@app.post("/api/review")
async def submit_review(req: ReviewRequest, tenant: dict = Depends(get_tenant)):
    """
    提交合规审查请求（中台核心 API）。

    多前台系统（法务/合同/采购）通过此 API 消费合规审查能力。
    """
    task_id = f"task_{uuid.uuid4().hex[:8]}"
    logger.info(
        "review_submitted task_id=%s tenant=%s domain=%s pipeline=%s content_len=%d",
        task_id, tenant["tenant_id"], req.compliance_domain, req.pipeline, len(req.document_content),
    )

    # 委托给 Agent 编排引擎
    # 生产环境应通过 HTTP 调用 orchestrator
    # 这里返回模拟响应展示 API 契约
    return {
        "status": "accepted",
        "task_id": task_id,
        "tenant_id": tenant["tenant_id"],
        "pipeline": req.pipeline,
        "estimated_steps": 4,
        "tracking_url": f"/api/tasks/{task_id}",
    }


@app.get("/api/knowledge/clauses")
async def search_clauses(
    q: str = "",
    domain: str = "",
    risk: str = "",
    tenant: dict = Depends(get_tenant),
):
    """查询知识库条款"""
    from services.knowledge_base.manager import KnowledgeBase

    kb = KnowledgeBase()
    if q:
        clauses = kb.search_clauses(q)
    else:
        clauses = kb.list_clauses(domain=domain or None, risk_level=risk or None)
    return {"total": len(clauses), "items": clauses}


@app.get("/api/knowledge/redlines")
async def list_redlines(domain: str = "", tenant: dict = Depends(get_tenant)):
    """查询红线条款"""
    from services.knowledge_base.manager import KnowledgeBase

    kb = KnowledgeBase()
    redlines = kb.list_redlines(domain=domain or None)
    return {"total": len(redlines), "items": redlines}


@app.get("/api/knowledge/stats")
async def knowledge_stats(tenant: dict = Depends(get_tenant)):
    """知识库统计"""
    from services.knowledge_base.manager import KnowledgeBase

    kb = KnowledgeBase()
    return kb.get_stats()


@app.get("/health")
async def health():
    return {
        "status": "ok",
        "service": "api-gateway",
        "version": "2.0.0",
        "tenants": len(tenant_manager._tenants),
    }


# ─── 入口 ─────────────────────────────────────────────────────

if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8080, log_level="info")
