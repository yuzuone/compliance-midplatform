"""
端到端测试脚本 — 验证完整的合规审查工作流。

测试场景: 模拟一份有合规风险的数据处理协议的自动审查过程。

运行方式:
    python tests/test_e2e_compliance.py
"""

import sys
import os
import json

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

# ─── 测试文档内容 ───────────────────────────────────────────────

TEST_DOCUMENT = """
数据处理与共享协议

甲方：张三（以下简称"数据提供方"）
法定代表人：李四
联系电话：13800138000
电子邮箱：zhangsan@example.com

第一条 数据提供
1.1 甲方同意向乙方（某云计算有限公司）提供以下用户个人信息：
    - 用户姓名
    - 身份证号码
    - 手机号码
    - 电子邮箱
    - 家庭住址
    - 银行账号及交易记录
    - 设备指纹及浏览历史
1.2 上述数据的处理目的为：产品功能实现、用户体验优化、市场分析、
    广告投放以及向第三方合作伙伴共享。

第二条 数据存储与传输
2.1 所有数据将存储在乙方位于美国弗吉尼亚州的 AWS 数据中心。
2.2 乙方可在未另行通知甲方的情况下，将数据传输至其位于
    新加坡、印度和德国的分支机构进行处理。
2.3 数据传输采用 AES-256 加密，无需向监管部门申报。

第三条 用户权利
3.1 用户可通过邮件联系客服查询其个人信息。
3.2 用户无权要求删除已收集的个人信息。

第四条 违约责任
4.1 任何一方违反本协议约定，应赔偿对方因此遭受的损失。
"""

# ─── 期望的审查发现 ────────────────────────────────────────────

EXPECTED_FINDINGS = [
    {
        "description": "违反最小必要原则 — 收集信息范围过宽",
        "severity": "critical",
        "check": lambda text: "姓名" in text or "身份证" in text,
    },
    {
        "description": "违反单独同意 — 多项处理目的捆绑授权",
        "severity": "high",
        "check": lambda text: "市场分析" in text or "广告投放" in text,
    },
    {
        "description": "违反数据出境安全评估 — 未通过评估即出境",
        "severity": "critical",
        "check": lambda text: "美国" in text or "AWS" in text,
    },
    {
        "description": "违反删除权 — 剥夺用户数据删除权利",
        "severity": "high",
        "check": lambda text: "无权要求删除" in text,
    },
]


def test_pii_gateway():
    """测试 1: PII 脱敏网关 — 实体识别与脱敏"""
    print("\n" + "=" * 60)
    print("测试 1: PII 脱敏网关")
    print("=" * 60)

    from services.pii_gateway.ner_engine import PIIEngine

    engine = PIIEngine(strategy="mask")
    result = engine.desensitize(TEST_DOCUMENT)

    print(f"  识别到 {result.entity_count} 个 PII 实体:")
    for e in result.entities:
        print(f"    [{e.entity_type}] {e.original_text} → {e.masked_text}")

    # 断言: 必须识别出至少 3 个 PII 实体
    assert result.entity_count >= 3, f"期望 >= 3, 实际 {result.entity_count}"

    # 断言: 脱敏后内容不等于原始内容
    assert result.desensitized_content != TEST_DOCUMENT

    # 断言: 原始内容中的敏感信息不再出现在脱敏后
    assert "13800138000" not in result.desensitized_content
    assert "zhangsan@example.com" not in result.desensitized_content

    print("  ✓ PII 脱敏网关测试通过")
    return result


def test_knowledge_graph():
    """测试 2: 知识图谱 Schema 验证（不依赖实际 Neo4j 连接）"""
    print("\n" + "=" * 60)
    print("测试 2: 知识图谱 Schema")
    print("=" * 60)

    from services.knowledge_graph.schema import SCHEMA_CYPHER

    # 验证 Schema 包含了必要的元素
    assert "Regulation" in SCHEMA_CYPHER, "缺少 Regulation 节点"
    assert "Clause" in SCHEMA_CYPHER, "缺少 Clause 节点"
    assert "RedLine" in SCHEMA_CYPHER, "缺少 RedLine 节点"
    assert "Playbook" in SCHEMA_CYPHER, "缺少 Playbook 节点"
    assert "ComplianceDomain" in SCHEMA_CYPHER, "缺少 ComplianceDomain 节点"
    assert "ReviewCase" in SCHEMA_CYPHER, "缺少 ReviewCase 节点"

    # 验证全文索引
    assert "FULLTEXT INDEX" in SCHEMA_CYPHER, "缺少全文索引"

    print("  ✓ 知识图谱 Schema 验证通过")
    print(f"  包含 6 种节点类型, 3 个全文索引")


def test_word_renderer():
    """测试 3: Word 红线批注引擎"""
    print("\n" + "=" * 60)
    print("测试 3: Word 红线批注引擎")
    print("=" * 60)

    from docx import Document
    from services.document_engine.word_renderer import (
        WordRedlineEngine,
        AnnotationInstruction,
    )

    # 创建测试文档
    template_path = "output/e2e_test_template.docx"
    os.makedirs("output", exist_ok=True)
    doc = Document()
    doc.add_heading("合规审查测试文档", level=1)
    doc.add_paragraph("这是一份包含违规条款的测试文档。")
    doc.save(template_path)

    # 批注指令
    instructions = [
        AnnotationInstruction(
            annotation_type="replace",
            original_text="违规内容A",
            suggested_text="合规内容A",
            comment_text="违反 GDPR Art.5",
            severity="critical",
            playbook_ref="RL-001",
        ),
        AnnotationInstruction(
            annotation_type="delete",
            original_text="违规内容B",
            comment_text="此条款应删除",
            severity="high",
            playbook_ref="RL-002",
        ),
        AnnotationInstruction(
            annotation_type="comment",
            comment_text="建议增加数据主体权利响应条款",
            severity="medium",
            playbook_ref="RL-005",
        ),
    ]

    # 渲染
    engine = WordRedlineEngine()
    output_path = engine.render(template_path, instructions, "output/e2e_test_redlined.docx")

    # 断言: 输出文件存在且大于模板
    assert os.path.exists(output_path), f"输出文件不存在: {output_path}"
    template_size = os.path.getsize(template_path)
    output_size = os.path.getsize(output_path)
    assert output_size > template_size, f"输出文件({output_size})应大于模板({template_size})"

    print(f"  ✓ Word 红线批注引擎测试通过")
    print(f"  模板: {template_size} bytes → 输出: {output_size} bytes")


def test_mcp_protocol():
    """测试 4: MCP 协议消息序列化/反序列化"""
    print("\n" + "=" * 60)
    print("测试 4: MCP 协议")
    print("=" * 60)

    from shared.mcp_protocol import (
        MCPRequest,
        MCPResponse,
        MCP_TOOLS,
        ComplianceFinding,
        DocumentAnnotation,
        AnnotationType,
        ReviewSeverity,
    )

    # 测试请求序列化
    req = MCPRequest(method="tools/call", params={"name": "render_redline_document"})
    raw = req.to_json()
    parsed = MCPRequest.from_json(raw)
    assert parsed.method == "tools/call"
    print("  ✓ MCP 请求序列化/反序列化正常")

    # 测试响应序列化
    resp = MCPResponse(id="123", result={"status": "ok"})
    raw = resp.to_json()
    data = json.loads(raw)
    assert data["id"] == "123"
    assert data["result"]["status"] == "ok"
    print("  ✓ MCP 响应序列化正常")

    # 测试错误响应
    err = MCPResponse.error_response("456", -32600, "Invalid Request")
    assert err.error["code"] == -32600
    print("  ✓ MCP 错误响应正常")

    # 测试 MCP 工具定义
    assert len(MCP_TOOLS) == 4
    tool_names = [t["name"] for t in MCP_TOOLS]
    assert "render_redline_document" in tool_names
    assert "query_playbook" in tool_names
    assert "desensitize_document" in tool_names
    assert "compliance_review" in tool_names
    print(f"  ✓ MCP 工具定义完整 ({len(MCP_TOOLS)} 个工具)")

    # 测试领域模型
    finding = ComplianceFinding(
        severity=ReviewSeverity.CRITICAL,
        description="违反数据最小化原则",
        playbook_clause="RL-001",
    )
    assert finding.severity == ReviewSeverity.CRITICAL

    annotation = DocumentAnnotation(
        annotation_type=AnnotationType.REPLACE,
        original_text="旧文本",
        suggested_text="新文本",
    )
    assert annotation.annotation_type == AnnotationType.REPLACE

    print("  ✓ 领域模型（ComplianceFinding, DocumentAnnotation）正常")


def test_config():
    """测试 5: 配置模块"""
    print("\n" + "=" * 60)
    print("测试 5: 配置模块")
    print("=" * 60)

    from shared.config import config

    assert config.pii_gateway_port > 0
    assert config.knowledge_graph_port > 0
    assert config.document_engine_port > 0
    assert config.pii_strategy in ("mask", "replace", "redact")

    print(f"  ✓ 配置加载正常")
    print(f"  PII 网关端口: {config.pii_gateway_port}")
    print(f"  知识图谱端口: {config.knowledge_graph_port}")
    print(f"  文档引擎端口: {config.document_engine_port}")
    print(f"  脱敏策略: {config.pii_strategy}")


def test_architecture_constraints():
    """测试 6: 架构约束验证（脑手分离）"""
    print("\n" + "=" * 60)
    print("测试 6: 架构约束验证")
    print("=" * 60)

    # 验证: PII 网关不依赖任何外部 API（代码审查）
    from services.pii_gateway.ner_engine import PIIEngine

    source = open(
        os.path.join(
            os.path.dirname(__file__),
            "../services/pii_gateway/ner_engine.py",
        ),
        encoding="utf-8",
    ).read()

    # 确保没有 HTTP 请求库的导入
    forbidden_imports = ["requests", "httpx", "urllib.request", "aiohttp"]
    for imp in forbidden_imports:
        assert f"import {imp}" not in source, f"PII 网关不应导入外部HTTP库: {imp}"
    print("  ✓ PII 网关: 纯本地运行，无外部API依赖")

    # 验证: 文档引擎不导入 LLM 相关库
    doc_engine_source = open(
        os.path.join(
            os.path.dirname(__file__),
            "../services/document_engine/word_renderer.py",
        ),
        encoding="utf-8",
    ).read()

    llm_imports = ["openai", "anthropic", "langchain", "llama"]
    for imp in llm_imports:
        assert imp not in doc_engine_source, f"文档引擎不应导入LLM库: {imp}"
    print("  ✓ 文档引擎: 无LLM依赖，只接收结构化指令")

    # 验证: MCP 协议模块不包含业务逻辑
    mcp_source = open(
        os.path.join(
            os.path.dirname(__file__),
            "../shared/mcp_protocol.py",
        ),
        encoding="utf-8",
    ).read()

    # 确保 MCP 模块只定义协议，不实现具体逻辑
    assert "class MCPRequest" in mcp_source
    assert "class MCPResponse" in mcp_source
    print("  ✓ MCP 协议层: 纯协议定义，与业务逻辑物理隔离")

    print("\n  ✅ 所有架构约束检查通过")


def run_all_tests():
    """运行所有测试"""
    print("\n" + "█" * 60)
    print("  零信任合规审查中台 — 端到端测试")
    print("█" * 60)

    tests = [
        ("配置模块", test_config),
        ("MCP 协议", test_mcp_protocol),
        ("PII 脱敏网关", test_pii_gateway),
        ("知识图谱 Schema", test_knowledge_graph),
        ("Word 红线批注引擎", test_word_renderer),
        ("架构约束验证", test_architecture_constraints),
    ]

    passed = 0
    failed = 0

    for name, test_fn in tests:
        try:
            test_fn()
            passed += 1
        except Exception as e:
            print(f"\n  ✗ {name} 失败: {str(e)}")
            import traceback

            traceback.print_exc()
            failed += 1

    print("\n" + "=" * 60)
    print(f"  测试结果: {passed} 通过, {failed} 失败 (共 {len(tests)} 项)")
    print("=" * 60)

    return failed == 0


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)
