# Shared module for compliance midplatform
