"""
集中配置模块 — 所有环境变量在此验证，启动时 fail-fast。
设计原则：敏感配置绝不硬编码，必须通过环境变量注入。
"""

import os
from dataclasses import dataclass, field
from typing import Optional


def required_env(name: str) -> str:
    """读取必需的环境变量，缺失则立即报错（fail-fast）"""
    value = os.environ.get(name)
    if not value:
        raise RuntimeError(f"缺少必需的环境变量: {name}")
    return value


def optional_env(name: str, default: str = "") -> str:
    """读取可选环境变量"""
    return os.environ.get(name, default)


@dataclass(frozen=True)
class Config:
    """全局配置，frozen 确保运行时不可变"""

    # --- 服务端口 ---
    pii_gateway_port: int = int(optional_env("PII_GATEWAY_PORT", "8101"))
    knowledge_graph_port: int = int(optional_env("KNOWLEDGE_GRAPH_PORT", "8102"))
    document_engine_port: int = int(optional_env("DOCUMENT_ENGINE_PORT", "8103"))

    # --- Neo4j ---
    neo4j_uri: str = optional_env("NEO4J_URI", "bolt://localhost:7687")
    neo4j_user: str = optional_env("NEO4J_USER", "neo4j")
    neo4j_password: str = optional_env("NEO4J_PASSWORD", "changeme")  # 生产环境必须通过环境变量覆盖

    # --- PII 脱敏 ---
    pii_presidio_endpoint: str = optional_env(
        "PII_PRESIDIO_ENDPOINT", "http://localhost:5002"
    )
    # 脱敏策略: "mask" | "replace" | "redact"
    pii_strategy: str = optional_env("PII_STRATEGY", "mask")

    # --- LLM (可选: 合规研判用) ---
    llm_api_key: str = optional_env("LLM_API_KEY", "")
    llm_api_base: str = optional_env("LLM_API_BASE", "https://api.openai.com/v1")
    llm_model: str = optional_env("LLM_MODEL", "gpt-4o-mini")

    # --- 安全 ---
    mcp_auth_token: str = optional_env("MCP_AUTH_TOKEN", "")
    allowed_origins: str = optional_env("ALLOWED_ORIGINS", "http://localhost:3000")

    # --- 日志 ---
    log_level: str = optional_env("LOG_LEVEL", "INFO")


# 全局单例
config = Config()
