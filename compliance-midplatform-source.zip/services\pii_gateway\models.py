"""PII 脱敏网关 — Pydantic 模型定义"""

from pydantic import BaseModel, Field
from typing import Optional


class DesensitizeRequest(BaseModel):
    """脱敏请求"""
    content: str = Field(..., description="原始文档内容", min_length=1)
    strategy: str = Field(default="mask", description="脱敏策略: mask | replace | redact")
    entity_types: Optional[list[str]] = Field(
        default=None,
        description="要识别的实体类型，如 ['NAME', 'PHONE', 'EMAIL']，不传则全部识别",
    )


class PIIEntityOut(BaseModel):
    """PII 实体输出"""
    entity_type: str
    original_text: str
    masked_text: str
    start_pos: int
    end_pos: int
    confidence: float
    map_key: str


class DesensitizeResponse(BaseModel):
    """脱敏响应"""
    desensitized_content: str
    entity_count: int
    strategy: str
    entities: list[PIIEntityOut] = []


class RestoreRequest(BaseModel):
    """还原请求"""
    content: str = Field(..., description="需要还原的文本内容")
    map_keys: Optional[list[str]] = Field(
        default=None,
        description="要还原的映射键列表，不传则尝试还原全部",
    )


class RestoreResponse(BaseModel):
    """还原响应"""
    restored_content: str
    restored_count: int


class HealthResponse(BaseModel):
    """健康检查"""
    status: str
    version: str = "1.0.0"
    strategy: str
