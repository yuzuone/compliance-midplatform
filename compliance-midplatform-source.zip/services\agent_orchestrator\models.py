"""
Agent 中台 — 数据模型定义

核心概念:
  Agent      — 一个可被编排的智能体实例
  Capability — Agent 暴露的能力（对应 MCP Tool）
  Task       — 编排引擎分发的任务
  Pipeline   — 多个 Agent 组合成的审查流水线
  Tenant     — 租户（企业/部门），实现数据隔离
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from enum import Enum
from dataclasses import dataclass, field
from typing import Optional


# ─── Agent ─────────────────────────────────────────────────────

class AgentStatus(str, Enum):
    ONLINE = "online"
    OFFLINE = "offline"
    DEGRADED = "degraded"  # 部分能力不可用
    DRAINING = "draining"   # 正在下线，不接受新任务


class AgentType(str, Enum):
    PII_GATEWAY = "pii_gateway"
    KNOWLEDGE_GRAPH = "knowledge_graph"
    COMPLIANCE_JUDGE = "compliance_judge"
    DOCUMENT_ENGINE = "document_engine"
    ORCHESTRATOR = "orchestrator"


@dataclass
class AgentCapability:
    """Agent 的一项能力"""
    name: str                         # 能力名称（对应 MCP tool name）
    description: str
    input_schema: dict                # JSON Schema
    cost_estimate: float = 0.0        # 预估耗时(秒)
    required: bool = False            # 审查流程是否必需


@dataclass
class AgentRegistration:
    """Agent 注册信息"""
    agent_id: str = field(default_factory=lambda: f"agent_{uuid.uuid4().hex[:8]}")
    agent_type: AgentType = AgentType.PII_GATEWAY
    name: str = ""
    version: str = "1.0.0"
    endpoint: str = ""                # MCP endpoint 或 HTTP URL
    capabilities: list[AgentCapability] = field(default_factory=list)
    status: AgentStatus = AgentStatus.ONLINE
    last_heartbeat: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    metadata: dict = field(default_factory=dict)  # 扩展信息


# ─── Task ──────────────────────────────────────────────────────

class TaskStatus(str, Enum):
    PENDING = "pending"
    ASSIGNED = "assigned"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class TaskPriority(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class TaskStep:
    """流水线中的一个步骤"""
    step_id: str = field(default_factory=lambda: f"step_{uuid.uuid4().hex[:6]}")
    agent_type: AgentType = AgentType.PII_GATEWAY
    capability: str = ""              # 调用哪个能力
    input_mapping: dict = field(default_factory=dict)   # 输入参数映射
    status: TaskStatus = TaskStatus.PENDING
    result: Optional[dict] = None
    error: Optional[str] = None
    started_at: Optional[str] = None
    completed_at: Optional[str] = None


@dataclass
class OrchestrationTask:
    """编排任务"""
    task_id: str = field(default_factory=lambda: f"task_{uuid.uuid4().hex[:8]}")
    tenant_id: str = "default"
    pipeline_name: str = "compliance_review"
    steps: list[TaskStep] = field(default_factory=list)
    current_step_index: int = 0
    status: TaskStatus = TaskStatus.PENDING
    priority: TaskPriority = TaskPriority.MEDIUM
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    context: dict = field(default_factory=dict)  # 任务上下文（跨 Step 共享数据）
    audit_log: list[dict] = field(default_factory=list)


# ─── Pipeline ──────────────────────────────────────────────────

@dataclass
class PipelineDefinition:
    """审查流水线定义"""
    name: str
    display_name: str
    description: str
    version: str = "1.0.0"
    steps: list[dict] = field(default_factory=list)  # 预定义的步骤序列
    enabled: bool = True


# ─── Tenant ────────────────────────────────────────────────────

@dataclass
class Tenant:
    """租户（企业/部门）"""
    tenant_id: str
    name: str
    api_key_hash: str = ""
    allowed_pipelines: list[str] = field(default_factory=list)
    rate_limit: int = 100              # 每分钟请求数
    data_retention_days: int = 90
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    active: bool = True


# ─── Audit ─────────────────────────────────────────────────────

@dataclass
class AuditEntry:
    """审查审计日志"""
    audit_id: str = field(default_factory=lambda: f"audit_{uuid.uuid4().hex[:8]}")
    tenant_id: str = "default"
    task_id: str = ""
    action: str = ""                    # review_started / step_completed / review_finished
    agent_type: Optional[str] = None
    document_id: Optional[str] = None
    pii_count: int = 0
    finding_count: int = 0
    risk_level: Optional[str] = None
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    metadata: dict = field(default_factory=dict)


# ─── 预定义流水线 ──────────────────────────────────────────────

DEFAULT_PIPELINE = PipelineDefinition(
    name="compliance_review",
    display_name="合规审查流水线",
    description="标准四步合规审查: PII脱敏 → 知识检索 → 合规研判 → 文档批注",
    steps=[
        {
            "step_id": "pii_desensitize",
            "agent_type": "pii_gateway",
            "capability": "desensitize_document",
            "input_mapping": {"content": "$.context.document_content"},
        },
        {
            "step_id": "graphrag_search",
            "agent_type": "knowledge_graph",
            "capability": "query_playbook",
            "input_mapping": {
                "query": "$.steps.pii_desensitize.desensitized_content",
                "domain": "$.context.compliance_domain",
            },
        },
        {
            "step_id": "compliance_judge",
            "agent_type": "compliance_judge",
            "capability": "compliance_review",
            "input_mapping": {
                "desensitized_content": "$.steps.pii_desensitize.desensitized_content",
                "playbook_results": "$.steps.graphrag_search",
                "domain": "$.context.compliance_domain",
            },
        },
        {
            "step_id": "render_document",
            "agent_type": "document_engine",
            "capability": "render_redline_document",
            "input_mapping": {
                "annotations": "$.steps.compliance_judge.annotations",
                "output_path": "$.context.output_path",
            },
        },
    ],
)

# 精简流水线（跳过文档渲染，只做审查）
QUICK_REVIEW_PIPELINE = PipelineDefinition(
    name="quick_review",
    display_name="快速审查（无文档渲染）",
    description="PII脱敏 + 知识检索 + 合规研判，不生成 Word 文档",
    steps=DEFAULT_PIPELINE.steps[:3],
)

# PII 专项检查流水线
PII_ONLY_PIPELINE = PipelineDefinition(
    name="pii_scan",
    display_name="PII 专项扫描",
    description="仅执行 PII 实体识别与脱敏，不做合规研判",
    steps=DEFAULT_PIPELINE.steps[:1],
)
