"""
PII 脱敏网关 — FastAPI 服务入口

启动方式:
    python -m services.pii-gateway.main
    uvicorn services.pii-gateway.main:app --port 8101 --reload

API:
    POST /api/desensitize  — PII 识别 + 脱敏
    POST /api/restore       — 还原脱敏内容
    GET  /health            — 健康检查
"""

import sys
import os
import logging
import structlog
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

# 将项目根目录加入 path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))

from shared.config import config
from services.pii_gateway.models import (
    DesensitizeRequest,
    DesensitizeResponse,
    RestoreRequest,
    RestoreResponse,
    HealthResponse,
    PIIEntityOut,
)
from services.pii_gateway.ner_engine import PIIEngine, PIIMapStore

# ─── 日志 ──────────────────────────────────────────────────────
structlog.configure(
    processors=[
        structlog.stdlib.filter_by_level,
        structlog.stdlib.add_log_level,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.dev.ConsoleRenderer(),
    ],
    wrapper_class=structlog.stdlib.BoundLogger,
    context_class=dict,
    logger_factory=structlog.PrintLoggerFactory(),
)
log = structlog.get_logger()


# ─── 全局状态 ──────────────────────────────────────────────────

# 每个 PII 网关实例维护一个映射表（生产环境应替换为持久化存储）
pii_map_store = PIIMapStore()
pii_engine = PIIEngine(strategy=config.pii_strategy, map_store=pii_map_store)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """服务生命周期管理"""
    log.info("pii_gateway_starting", port=config.pii_gateway_port, strategy=config.pii_strategy)
    yield
    log.info("pii_gateway_stopping")
    # 清理映射表
    pii_map_store._store.clear()


# ─── FastAPI 应用 ──────────────────────────────────────────────

app = FastAPI(
    title="PII 脱敏网关",
    description="零信任合规审查中台 — PII 实体识别与匿名化处理微服务",
    version="1.0.0",
    lifespan=lifespan,
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=config.allowed_origins.split(","),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ─── API 端点 ──────────────────────────────────────────────────

@app.get("/health", response_model=HealthResponse)
async def health_check():
    """健康检查"""
    return HealthResponse(
        status="ok",
        version="1.0.0",
        strategy=pii_engine.strategy,
    )


@app.post("/api/desensitize", response_model=DesensitizeResponse)
async def desensitize(request: DesensitizeRequest):
    """
    PII 实体识别与脱敏处理。

    对传入的文本内容进行 PII 实体识别，按指定策略脱敏后返回。
    脱敏后的内容可以安全地传入云端 LLM 进行分析。

    示例:
        POST /api/desensitize
        {
            "content": "张三的联系方式: 13800138000, 邮箱 zhangsan@example.com",
            "strategy": "mask"
        }

    返回:
        {
            "desensitized_content": "张*的联系方式: 138****8000, 邮箱 zh***@example.com",
            "entity_count": 3,
            "entities": [...]
        }
    """
    log.info("desensitize_request", content_len=len(request.content), strategy=request.strategy)

    try:
        result = pii_engine.desensitize(
            content=request.content,
            entity_types=request.entity_types,
        )

        log.info("desensitize_complete", entity_count=result.entity_count)

        return DesensitizeResponse(
            desensitized_content=result.desensitized_content,
            entity_count=result.entity_count,
            strategy=result.strategy,
            entities=[
                PIIEntityOut(
                    entity_type=e.entity_type,
                    original_text=e.original_text,
                    masked_text=e.masked_text,
                    start_pos=e.start_pos,
                    end_pos=e.end_pos,
                    confidence=e.confidence,
                    map_key=e.map_key,
                )
                for e in result.entities
            ],
        )
    except Exception as e:
        log.error("desensitize_error", error=str(e))
        raise HTTPException(status_code=500, detail=f"脱敏处理失败: {str(e)}")


@app.post("/api/restore", response_model=RestoreResponse)
async def restore(request: RestoreRequest):
    """
    还原脱敏内容（将替换标记恢复为原始 PII 数据）。

    仅在本地网络内使用，不对 LLM 暴露此端点。

    示例:
        POST /api/restore
        {
            "content": "<NAME_001>的联系方式: <PHONE_001>"
        }
    """
    log.info("restore_request", content_len=len(request.content))

    try:
        restored = pii_map_store.restore(request.content)
        # 计算实际还原了多少
        restored_count = len(request.content) - len(request.content.replace("<", ""))

        return RestoreResponse(
            restored_content=restored,
            restored_count=restored_count,
        )
    except Exception as e:
        log.error("restore_error", error=str(e))
        raise HTTPException(status_code=500, detail=f"还原失败: {str(e)}")


# ─── 程序入口 ──────────────────────────────────────────────────

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "services.pii_gateway.main:app",
        host="0.0.0.0",
        port=config.pii_gateway_port,
        log_level=config.log_level.lower(),
    )
