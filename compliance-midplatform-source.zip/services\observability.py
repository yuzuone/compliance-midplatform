"""
中台可观测性基础设施 — 结构化日志 / 指标 / 审计追踪。

职责:
  1. 结构化日志 — 所有服务统一日志格式, request_id 贯穿全链路
  2. 指标暴露 — Prometheus 格式的 /metrics 端点
  3. 审计追踪 — 谁在什么时候做了什么操作
  4. 健康仪表 — 中台服务健康状态聚合
"""

import time
import json
import logging
from datetime import datetime, timezone
from collections import defaultdict
from typing import Optional


# ─── 结构化日志 ─────────────────────────────────────────────────

class StructuredLogger:
    """中台统一日志格式化器"""

    def __init__(self, service_name: str):
        self.service_name = service_name
        self._logger = logging.getLogger(service_name)

    def _format(self, level: str, message: str, **kwargs) -> str:
        entry = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "level": level,
            "service": self.service_name,
            "message": message,
            **kwargs,
        }
        return json.dumps(entry, ensure_ascii=False, default=str)

    def info(self, message: str, **kwargs):
        self._logger.info(self._format("INFO", message, **kwargs))

    def warn(self, message: str, **kwargs):
        self._logger.warning(self._format("WARN", message, **kwargs))

    def error(self, message: str, **kwargs):
        self._logger.error(self._format("ERROR", message, **kwargs))

    def audit(self, action: str, tenant_id: str, **kwargs):
        """审计专用日志"""
        self._logger.info(self._format("AUDIT", action, tenant_id=tenant_id, **kwargs))


# ─── 指标收集器 ─────────────────────────────────────────────────

class MetricsCollector:
    """简易指标收集器（生产环境应使用 Prometheus client）"""

    def __init__(self):
        self._counters: dict[str, int] = defaultdict(int)
        self._histograms: dict[str, list[float]] = defaultdict(list)
        self._gauges: dict[str, float] = defaultdict(float)

    def increment(self, name: str, value: int = 1, labels: Optional[dict] = None):
        key = self._metric_key(name, labels)
        self._counters[key] += value

    def observe(self, name: str, value: float, labels: Optional[dict] = None):
        key = self._metric_key(name, labels)
        self._histograms[key].append(value)

    def set_gauge(self, name: str, value: float, labels: Optional[dict] = None):
        key = self._metric_key(name, labels)
        self._gauges[key] = value

    def get_prometheus_text(self) -> str:
        """输出 Prometheus 格式"""
        lines = []
        for key, value in self._counters.items():
            lines.append(f"# TYPE {self._extract_name(key)} counter")
            lines.append(f"{key} {value}")
        for key, values in self._histograms.items():
            name = self._extract_name(key)
            lines.append(f"# TYPE {name} histogram")
            if values:
                lines.append(f"{name}_count {len(values)}")
                lines.append(f"{name}_sum {sum(values):.2f}")
        for key, value in self._gauges.items():
            lines.append(f"# TYPE {self._extract_name(key)} gauge")
            lines.append(f"{key} {value}")
        return "\n".join(lines) + "\n"

    def _metric_key(self, name: str, labels: Optional[dict]) -> str:
        if labels:
            label_str = ",".join(f'{k}="{v}"' for k, v in sorted(labels.items()))
            return f"{name}{{{label_str}}}"
        return name

    def _extract_name(self, key: str) -> str:
        return key.split("{")[0] if "{" in key else key


# 全局指标实例
metrics = MetricsCollector()


# ─── 审计追踪 ──────────────────────────────────────────────────

class AuditTrail:
    """审查审计追踪"""

    def __init__(self, max_entries: int = 1000):
        self._entries: list[dict] = []
        self._max_entries = max_entries

    def record(
        self,
        action: str,
        tenant_id: str,
        task_id: str = "",
        document_id: str = "",
        details: Optional[dict] = None,
    ):
        entry = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "action": action,
            "tenant_id": tenant_id,
            "task_id": task_id,
            "document_id": document_id,
            "details": details or {},
        }
        self._entries.append(entry)
        if len(self._entries) > self._max_entries:
            self._entries = self._entries[-self._max_entries:]

    def query(
        self,
        tenant_id: Optional[str] = None,
        action: Optional[str] = None,
        limit: int = 50,
    ) -> list[dict]:
        results = self._entries
        if tenant_id:
            results = [e for e in results if e["tenant_id"] == tenant_id]
        if action:
            results = [e for e in results if e["action"] == action]
        return results[-limit:]

    def clear(self):
        self._entries.clear()


audit_trail = AuditTrail()


# ─── 健康聚合 ──────────────────────────────────────────────────

class HealthAggregator:
    """聚合所有中台服务的健康状态"""

    def __init__(self):
        self._services: dict[str, dict] = {}

    def report(self, service_name: str, status: str, **details):
        self._services[service_name] = {
            "status": status,
            "last_report": datetime.now(timezone.utc).isoformat(),
            "details": details,
        }

    def get_overall_status(self) -> dict:
        services = {}
        healthy = 0
        unhealthy = 0
        for name, info in self._services.items():
            services[name] = info["status"]
            if info["status"] == "healthy":
                healthy += 1
            else:
                unhealthy += 1

        return {
            "overall": "healthy" if unhealthy == 0 else "degraded" if healthy > 0 else "unhealthy",
            "healthy": healthy,
            "unhealthy": unhealthy,
            "services": services,
        }


health_aggregator = HealthAggregator()
