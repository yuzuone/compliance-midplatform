"""
Neo4j 合规知识图谱 — 图 Schema 设计与初始化

知识图谱节点与关系：

    (Regulation)-[:CONTAINS]->(Clause)
    (Clause)-[:VIOLATES]->(RedLine)
    (RedLine)-[:BELONGS_TO]->(ComplianceDomain)
    (RedLine)-[:REFERENCED_BY]->(Playbook)
    (Playbook)-[:APPLIES_TO]->(ComplianceDomain)
    (ReviewCase)-[:FOUND_VIOLATION]->(RedLine)
    (ReviewCase)-[:RELATES_TO]->(Clause)

查询模式（GraphRAG）:
    1. 关键词匹配 → 直达特定条款
    2. 领域过滤 → 缩小到合规领域
    3. 图遍历 → 从条款追踪到红线 → 到 Playbook
    4. 相似案例 → 查找类似审查案例的判决结果
"""

import logging
from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from neo4j import Driver, Session

logger = logging.getLogger(__name__)

# ─── Cypher 建图语句 ──────────────────────────────────────────────

SCHEMA_CYPHER = """
// 约束与索引
CREATE CONSTRAINT regulation_name IF NOT EXISTS
FOR (r:Regulation) REQUIRE r.name IS UNIQUE;

CREATE CONSTRAINT clause_id IF NOT EXISTS
FOR (c:Clause) REQUIRE c.clause_id IS UNIQUE;

CREATE CONSTRAINT redline_id IF NOT EXISTS
FOR (rl:RedLine) REQUIRE rl.redline_id IS UNIQUE;

CREATE CONSTRAINT playbook_id IF NOT EXISTS
FOR (p:Playbook) REQUIRE p.playbook_id IS UNIQUE;

CREATE CONSTRAINT domain_name IF NOT EXISTS
FOR (d:ComplianceDomain) REQUIRE d.name IS UNIQUE;

CREATE CONSTRAINT case_id IF NOT EXISTS
FOR (c:ReviewCase) REQUIRE c.case_id IS UNIQUE;

// 全文索引 (用于 GraphRAG 关键词检索)
CREATE FULLTEXT INDEX clause_text_index IF NOT EXISTS
FOR (c:Clause) ON EACH [c.title, c.content];

CREATE FULLTEXT INDEX redline_text_index IF NOT EXISTS
FOR (rl:RedLine) ON EACH [rl.title, rl.description];

CREATE FULLTEXT INDEX playbook_text_index IF NOT EXISTS
FOR (p:Playbook) ON EACH [p.title, p.content];
"""

# ─── Neo4j 连接管理 ──────────────────────────────────────────────

class Neo4jConnection:
    """Neo4j 数据库连接管理器（连接池）"""

    def __init__(self, uri: str, user: str, password: str):
        from neo4j import GraphDatabase

        self._driver: Optional["Driver"] = None
        self._uri = uri
        self._user = user
        self._password = password
        self._GraphDatabase = GraphDatabase

    @property
    def driver(self) -> "Driver":
        if self._driver is None:
            self._driver = self._GraphDatabase.driver(
                self._uri,
                auth=(self._user, self._password),
                max_connection_lifetime=3600,
                max_connection_pool_size=10,
            )
            logger.info("neo4j_connected", uri=self._uri)
        return self._driver

    def close(self):
        if self._driver:
            self._driver.close()
            self._driver = None

    def session(self, database: str = "neo4j") -> "Session":
        return self.driver.session(database=database)

    def verify_connectivity(self) -> bool:
        """验证数据库连接"""
        try:
            self.driver.verify_connectivity()
            return True
        except Exception as e:
            logger.error("neo4j_connect_failed", error=str(e))
            return False


# ─── Schema 初始化 ───────────────────────────────────────────────

def init_schema(conn: Neo4jConnection) -> None:
    """初始化知识图谱 Schema（创建约束和索引）"""
    with conn.session() as session:
        # 分条执行（Neo4j 不支持批量 schema 语句）
        statements = [s.strip() for s in SCHEMA_CYPHER.split(";") if s.strip()]
        for stmt in statements:
            try:
                session.run(stmt)
                logger.debug("schema_executed", statement=stmt[:80])
            except Exception as e:
                # 约束已存在不算错误
                if "already exists" in str(e):
                    logger.debug("schema_already_exists", statement=stmt[:80])
                else:
                    logger.warning("schema_error", error=str(e), statement=stmt[:80])

    logger.info("schema_initialized")
