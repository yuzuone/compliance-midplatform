# 零信任合规审查中台 — 项目概述

## 已实现功能

### 1. "脑手分离"多智能体微服务架构
- 合规决策逻辑（脑）与文档渲染引擎（手）通过 MCP 协议物理隔离
- 三条安全铁律强制约束：原始文档不出本地、LLM 只收脱敏数据、文档引擎不收自由文本

### 2. PII 脱敏网关 (`services/pii_gateway/`)
- 纯本地 NER 引擎（零外部 API 依赖），7 类中文 PII 实体识别
- 三种脱敏策略：mask（遮盖）、replace（伪名替换+可反向映射）、redact（完全遮盖）
- FastAPI REST API + MCP 工具接口双模式

### 3. Neo4j 合规知识图谱 + GraphRAG (`services/knowledge_graph/`)
- 6 种节点类型（Regulation/Clause/RedLine/Playbook/ComplianceDomain/ReviewCase）
- 覆盖 GDPR、PIPL、CCPA、数据出境安全评估办法、EU AI Act
- 三层 GraphRAG 检索：全文索引 → 图遍历 → 案例追溯
- 6 条企业红线条款 Playbook（含修复建议）+ 3 个历史审查案例
- 3 个全文索引支持语义检索

### 4. MCP Word 文档渲染引擎 (`services/document_engine/`)
- 支持 5 种批注类型：delete（红色删除线）、insert（蓝色下划线）、replace（红删+蓝增）、comment（批注）、highlight（黄色高亮）
- 审查封面页 + 审查汇总页 + 严重程度颜色编码
- MCP Server 双传输模式：stdio（Dify 集成）+ HTTP（REST 调试）

### 5. Dify 工作流集成 (`dify/`)
- 完整 8 节点工作流 DSL：文档输入 → PII 脱敏 → GraphRAG 检索 → LLM 研判 → JSON 解析 → 文档渲染
- MCP 工具注册配置，3 个服务自动发现

### 6. Docker Compose 一键部署
- 4 个微服务容器（含 Neo4j 知识图谱数据库）
- 健康检查、网络隔离、卷持久化

## 技术栈
- **Backend**: Python 3.13 + FastAPI + Pydantic
- **PII 引擎**: 正则 NER（可扩展 Presidio）
- **知识图谱**: Neo4j 5.x + Cypher + 全文索引
- **文档处理**: python-docx（红线批注/修订模拟）
- **MCP 协议**: 自定义 JSON-RPC 2.0 实现 + MCP SDK
- **编排**: Dify + Docker Compose

## 关键文件
```
compliance-midplatform/
├── ARCHITECTURE.md              ← 架构设计文档（数据流图+安全边界）
├── docker-compose.yml           ← 一键部署
├── shared/
│   ├── config.py                ← 集中配置（fail-fast 环境变量验证）
│   └── mcp_protocol.py          ← MCP 协议定义 + 领域模型
├── services/
│   ├── pii_gateway/             ← PII 脱敏网关
│   │   ├── ner_engine.py        ← 核心 NER 引擎
│   │   └── main.py              ← FastAPI 服务
│   ├── knowledge_graph/         ← 知识图谱服务
│   │   ├── schema.py            ← Neo4j Schema + 连接管理
│   │   ├── seed_data.py         ← 种子数据（GDPR/PIPL/CCPA 条款）
│   │   ├── graph_rag.py         ← GraphRAG 检索引擎
│   │   └── main.py              ← FastAPI 服务
│   └── document_engine/         ← 文档渲染引擎
│       ├── word_renderer.py     ← Word 红线批注引擎
│       └── server.py            ← MCP Server（stdio + HTTP）
├── dify/
│   ├── workflow.yml             ← Dify 工作流 DSL
│   └── mcp_config.json          ← MCP 工具注册
└── tests/
    └── test_e2e_compliance.py   ← 端到端测试（6 项全部通过）
```

## 端到端测试结果
```
测试 1: PII 脱敏网关         ✓ 18 个 PII 实体正确识别和脱敏
测试 2: 知识图谱 Schema      ✓ 6 种节点类型, 3 个全文索引
测试 3: Word 红线批注引擎     ✓ 文档正确生成 (38KB+)
测试 4: MCP 协议             ✓ 序列化/反序列化/工具定义
测试 5: 配置模块              ✓ Fail-fast 环境验证
测试 6: 架构约束验证          ✓ 脑手分离三条铁律全部通过
```

## 后续可扩展方向
1. 接入 Microsoft Presidio 提升 PII 识别精度
2. Neo4j 向量索引（GraphRAG 语义检索增强）
3. 真正的 Word Track Changes (python-docx 限制)
4. Web UI Dashboard (React + FluxUI)
5. 对接企业 SSO + RBAC 权限控制
