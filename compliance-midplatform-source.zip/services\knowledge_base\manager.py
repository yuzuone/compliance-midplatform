"""
合规知识库管理系统 — 中台数据层。

设计:
  - SQLite 作为主存储（始终可用）
  - Neo4j 作为图查询引擎（可选同步）
  - 每条知识条目带版本号、审核状态、数据来源
  - 支持批量导入/导出

知识条目类型:
  regulation  — 法规（GDPR/PIPL/CCPA/...）
  clause      — 条款（具体条文）
  redline     — 红线条款（企业合规底线）
  playbook    — 合规手册/操作指引
  case        — 审查案例
"""

import sqlite3
import json
import os
from datetime import datetime, timezone
from typing import Optional

DB_PATH = os.path.join(os.path.dirname(__file__), "knowledge_base.db")


def get_db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH, timeout=5)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=DELETE")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA busy_timeout=3000")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db():
    """创建知识库表结构"""
    conn = get_db()
    conn.executescript("""
        -- 法规
        CREATE TABLE IF NOT EXISTS regulations (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL UNIQUE,
            full_name TEXT,
            jurisdiction TEXT NOT NULL,
            effective_date TEXT,
            status TEXT DEFAULT 'active',      -- active | superseded | repealed
            version INTEGER DEFAULT 1,
            source_url TEXT,                    -- 官方来源 URL
            source_name TEXT,                   -- 来源名称
            last_updated TEXT,
            created_at TEXT DEFAULT (datetime('now')),
            updated_at TEXT DEFAULT (datetime('now'))
        );

        -- 条款
        CREATE TABLE IF NOT EXISTS clauses (
            id TEXT PRIMARY KEY,
            regulation_id TEXT NOT NULL REFERENCES regulations(id),
            article_number TEXT NOT NULL,       -- 条款编号
            title TEXT NOT NULL,
            content TEXT NOT NULL,
            risk_level TEXT DEFAULT 'medium',   -- critical | high | medium | low
            compliance_domain TEXT,             -- data_privacy | cross_border | ai | export_control
            status TEXT DEFAULT 'draft',        -- draft | reviewed | published | deprecated
            version INTEGER DEFAULT 1,
            reviewer TEXT,                      -- 审核人
            reviewed_at TEXT,
            source_page TEXT,                   -- 原文页码
            created_at TEXT DEFAULT (datetime('now')),
            updated_at TEXT DEFAULT (datetime('now')),
            UNIQUE(regulation_id, article_number)
        );

        -- 红线条款 (企业自定义)
        CREATE TABLE IF NOT EXISTS redlines (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            description TEXT NOT NULL,
            remediation TEXT,                   -- 修复建议
            priority TEXT DEFAULT 'high',       -- critical | high | medium | low
            compliance_domain TEXT,
            related_clause_ids TEXT,            -- JSON list of clause IDs
            status TEXT DEFAULT 'draft',
            version INTEGER DEFAULT 1,
            author TEXT,
            created_at TEXT DEFAULT (datetime('now')),
            updated_at TEXT DEFAULT (datetime('now'))
        );

        -- 合规手册/Playbook
        CREATE TABLE IF NOT EXISTS playbooks (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            content TEXT NOT NULL,
            compliance_domain TEXT,
            related_redline_ids TEXT,           -- JSON list
            status TEXT DEFAULT 'draft',
            version INTEGER DEFAULT 1,
            created_at TEXT DEFAULT (datetime('now')),
            updated_at TEXT DEFAULT (datetime('now'))
        );

        -- 审查案例
        CREATE TABLE IF NOT EXISTS cases (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            summary TEXT,
            outcome TEXT,
            severity TEXT DEFAULT 'medium',
            compliance_domain TEXT,
            related_redline_ids TEXT,
            related_clause_ids TEXT,
            status TEXT DEFAULT 'draft',
            created_at TEXT DEFAULT (datetime('now'))
        );

        -- 数据变更日志（审计）
        CREATE TABLE IF NOT EXISTS audit_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            table_name TEXT NOT NULL,
            record_id TEXT NOT NULL,
            action TEXT NOT NULL,               -- create | update | delete
            old_values TEXT,                    -- JSON
            new_values TEXT,                    -- JSON
            changed_by TEXT DEFAULT 'system',
            changed_at TEXT DEFAULT (datetime('now'))
        );

        -- 全文索引（SQLite FTS5）
        CREATE VIRTUAL TABLE IF NOT EXISTS clauses_fts USING fts5(
            title, content, article_number,
            content='clauses',
            content_rowid='rowid'
        );

        CREATE VIRTUAL TABLE IF NOT EXISTS redlines_fts USING fts5(
            title, description,
            content='redlines',
            content_rowid='rowid'
        );
    """)
    conn.commit()
    conn.close()


# ─── CRUD 操作 ─────────────────────────────────────────────────

class KnowledgeBase:
    """知识库管理器"""
    _db_initialized = False

    def __init__(self):
        if not KnowledgeBase._db_initialized:
            init_db()
            KnowledgeBase._db_initialized = True

    # ─── 法规 ───────────────────────────────────────────────

    def create_regulation(self, data: dict) -> dict:
        conn = get_db()
        conn.execute("""
            INSERT INTO regulations (id, name, full_name, jurisdiction, effective_date, source_url, source_name)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            data["id"], data["name"], data.get("full_name", ""),
            data["jurisdiction"], data.get("effective_date", ""),
            data.get("source_url", ""), data.get("source_name", ""),
        ))
        conn.commit()
        conn.close()
        return self.get_regulation(data["id"])

    def get_regulation(self, reg_id: str) -> Optional[dict]:
        conn = get_db()
        row = conn.execute("SELECT * FROM regulations WHERE id=?", (reg_id,)).fetchone()
        conn.close()
        return dict(row) if row else None

    def list_regulations(self, jurisdiction: Optional[str] = None) -> list[dict]:
        conn = get_db()
        if jurisdiction:
            rows = conn.execute(
                "SELECT * FROM regulations WHERE jurisdiction=? AND status='active' ORDER BY name",
                (jurisdiction,),
            ).fetchall()
        else:
            rows = conn.execute("SELECT * FROM regulations WHERE status='active' ORDER BY jurisdiction, name").fetchall()
        conn.close()
        return [dict(r) for r in rows]

    # ─── 条款 ───────────────────────────────────────────────

    def create_clause(self, data: dict) -> dict:
        conn = get_db()
        conn.execute("""
            INSERT INTO clauses (id, regulation_id, article_number, title, content,
                                 risk_level, compliance_domain, status, source_page)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            data["id"], data["regulation_id"], data["article_number"],
            data["title"], data["content"],
            data.get("risk_level", "medium"), data.get("compliance_domain", ""),
            data.get("status", "draft"), data.get("source_page", ""),
        ))
        conn.commit()
        conn.close()
        return self.get_clause(data["id"])

    def get_clause(self, clause_id: str) -> Optional[dict]:
        conn = get_db()
        row = conn.execute("SELECT * FROM clauses WHERE id=?", (clause_id,)).fetchone()
        conn.close()
        return dict(row) if row else None

    def list_clauses(
        self,
        regulation_id: Optional[str] = None,
        domain: Optional[str] = None,
        risk_level: Optional[str] = None,
        status: str = "published",
        limit: int = 50,
    ) -> list[dict]:
        conn = get_db()
        query = "SELECT * FROM clauses WHERE status=?"
        params = [status]
        if regulation_id:
            query += " AND regulation_id=?"
            params.append(regulation_id)
        if domain:
            query += " AND compliance_domain=?"
            params.append(domain)
        if risk_level:
            query += " AND risk_level=?"
            params.append(risk_level)
        query += " ORDER BY regulation_id, article_number LIMIT ?"
        params.append(limit)
        rows = conn.execute(query, params).fetchall()
        conn.close()
        return [dict(r) for r in rows]

    def search_clauses(self, query: str, limit: int = 20) -> list[dict]:
        """全文搜索条款"""
        conn = get_db()
        rows = conn.execute("""
            SELECT c.* FROM clauses c
            JOIN clauses_fts fts ON c.rowid = fts.rowid
            WHERE clauses_fts MATCH ? AND c.status = 'published'
            ORDER BY rank LIMIT ?
        """, (query, limit)).fetchall()
        conn.close()
        return [dict(r) for r in rows]

    def update_clause_status(self, clause_id: str, status: str, reviewer: str = "") -> dict:
        conn = get_db()
        conn.execute("""
            UPDATE clauses SET status=?, reviewer=?, reviewed_at=datetime('now'), updated_at=datetime('now')
            WHERE id=?
        """, (status, reviewer, clause_id))
        conn.commit()
        conn.close()
        return self.get_clause(clause_id)

    # ─── 红线条款 ───────────────────────────────────────────

    def create_redline(self, data: dict) -> dict:
        conn = get_db()
        conn.execute("""
            INSERT INTO redlines (id, title, description, remediation, priority,
                                  compliance_domain, related_clause_ids, author)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            data["id"], data["title"], data["description"],
            data.get("remediation", ""), data.get("priority", "high"),
            data.get("compliance_domain", ""),
            json.dumps(data.get("related_clause_ids", [])),
            data.get("author", "system"),
        ))
        conn.commit()
        conn.close()
        return self.get_redline(data["id"])

    def get_redline(self, redline_id: str) -> Optional[dict]:
        conn = get_db()
        row = conn.execute("SELECT * FROM redlines WHERE id=?", (redline_id,)).fetchone()
        conn.close()
        if row:
            d = dict(row)
            d["related_clause_ids"] = json.loads(d.get("related_clause_ids", "[]"))
            return d
        return None

    def list_redlines(self, domain: Optional[str] = None, status: str = "published") -> list[dict]:
        conn = get_db()
        query = "SELECT * FROM redlines WHERE status=?"
        params = [status]
        if domain:
            query += " AND compliance_domain=?"
            params.append(domain)
        query += " ORDER BY priority DESC"
        rows = conn.execute(query, params).fetchall()
        conn.close()
        return [dict(r) for r in rows]

    # ─── 批量导入 ───────────────────────────────────────────

    def import_from_dict(self, regulations: list[dict], clauses: list[dict], redlines: list[dict]):
        """从字典批量导入（用于种子数据迁移）"""
        for r in regulations:
            try:
                self.create_regulation(r)
            except sqlite3.IntegrityError:
                pass  # 已存在则跳过
        for c in clauses:
            try:
                self.create_clause(c)
            except sqlite3.IntegrityError:
                pass
        for rl in redlines:
            try:
                self.create_redline(rl)
            except sqlite3.IntegrityError:
                pass

    def export_all(self) -> dict:
        """导出全部知识库数据"""
        return {
            "regulations": self.list_regulations(),
            "clauses": self.list_clauses(status="published"),
            "redlines": self.list_redlines(),
            "exported_at": datetime.now(timezone.utc).isoformat(),
        }

    # ─── 统计 ───────────────────────────────────────────────

    def upsert_regulation(self, data: dict) -> bool:
        """INSERT OR REPLACE法规（快速，无额外查询）"""
        conn = get_db()
        conn.execute("""
            INSERT OR REPLACE INTO regulations (id, name, full_name, jurisdiction, effective_date, source_url, source_name)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            data["id"], data["name"], data.get("full_name", ""),
            data["jurisdiction"], data.get("effective_date", ""),
            data.get("source_url", ""), data.get("source_name", ""),
        ))
        conn.commit()
        conn.close()
        return True

    def bulk_create_clauses(self, clauses: list[dict]) -> int:
        """批量创建条款（executemany单事务，极致速度）"""
        if not clauses:
            return 0
        conn = get_db()
        try:
            conn.execute("BEGIN IMMEDIATE")
            cur = conn.executemany("""
                INSERT OR IGNORE INTO clauses (id, regulation_id, article_number, title, content,
                                 risk_level, compliance_domain, status, source_page)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, [
                (
                    d["id"], d["regulation_id"], d["article_number"],
                    d["title"], d["content"],
                    d.get("risk_level", "medium"), d.get("compliance_domain", ""),
                    d.get("status", "published"), d.get("source_page", ""),
                )
                for d in clauses
            ])
            conn.commit()
            return cur.rowcount
        finally:
            conn.close()

    def get_stats(self) -> dict:
        conn = get_db()
        stats = {}
        for table in ["regulations", "clauses", "redlines", "playbooks", "cases"]:
            row = conn.execute(f"SELECT COUNT(*) as cnt FROM {table}").fetchone()
            stats[table] = row["cnt"] if row else 0
        conn.close()
        return stats


# ─── 种子数据迁移 ──────────────────────────────────────────────

def migrate_seed_data():
    """将原来的手写种子数据迁移到知识库管理系统中"""
    kb = KnowledgeBase()

    regulations = [
        {"id": "GDPR", "name": "GDPR", "full_name": "General Data Protection Regulation",
         "jurisdiction": "EU", "effective_date": "2018-05-25",
         "source_url": "https://gdpr-info.eu/", "source_name": "Official EU GDPR Portal"},
        {"id": "PIPL", "name": "PIPL", "full_name": "中华人民共和国个人信息保护法",
         "jurisdiction": "China", "effective_date": "2021-11-01",
         "source_url": "https://www.npc.gov.cn/", "source_name": "全国人民代表大会"},
        {"id": "CCPA", "name": "CCPA", "full_name": "California Consumer Privacy Act",
         "jurisdiction": "US-CA", "effective_date": "2020-01-01",
         "source_url": "https://oag.ca.gov/privacy/ccpa", "source_name": "CA Attorney General"},
        {"id": "DSEA", "name": "数据出境安全评估办法",
         "full_name": "数据出境安全评估办法",
         "jurisdiction": "China", "effective_date": "2022-09-01",
         "source_url": "http://www.cac.gov.cn/", "source_name": "国家互联网信息办公室"},
        {"id": "EU_AI_Act", "name": "EU AI Act",
         "full_name": "EU Artificial Intelligence Act",
         "jurisdiction": "EU", "effective_date": "2024-08-01",
         "source_url": "https://artificialintelligenceact.eu/", "source_name": "EU AI Act Portal"},
    ]

    clauses = [
        {"id": "GDPR-Art5-1-c", "regulation_id": "GDPR", "article_number": "Art.5(1)(c)",
         "title": "数据最小化原则", "risk_level": "critical", "compliance_domain": "data_privacy",
         "content": "个人数据应充分、相关且限于处理目的所必需的范围。",
         "source_page": "Article 5, Paragraph 1(c)"},
        {"id": "GDPR-Art44", "regulation_id": "GDPR", "article_number": "Art.44",
         "title": "跨境数据传输原则", "risk_level": "critical", "compliance_domain": "cross_border_transfer",
         "content": "正在进行或将进行处理的个人数据转移到第三国或国际组织，控制者和处理者应遵守本章规定的条件。",
         "source_page": "Article 44"},
        {"id": "GDPR-Art17", "regulation_id": "GDPR", "article_number": "Art.17",
         "title": "删除权（被遗忘权）", "risk_level": "high", "compliance_domain": "data_privacy",
         "content": "数据主体有权要求控制者无不当延误地删除与其相关的个人数据。",
         "source_page": "Article 17"},
        {"id": "PIPL-Art13", "regulation_id": "PIPL", "article_number": "Art.13",
         "title": "个人信息处理告知同意", "risk_level": "critical", "compliance_domain": "data_privacy",
         "content": "个人信息处理者应在处理个人信息前，以显著方式、清晰易懂的语言向个人告知相关事项并取得同意。"},
        {"id": "PIPL-Art38", "regulation_id": "PIPL", "article_number": "Art.38",
         "title": "数据出境安全评估", "risk_level": "critical", "compliance_domain": "cross_border_transfer",
         "content": "个人信息处理者因业务需要确需向境外提供个人信息的，应通过国家网信部门组织的安全评估。"},
        {"id": "DSEA-Art4", "regulation_id": "DSEA", "article_number": "Art.4",
         "title": "安全评估触发条件", "risk_level": "critical", "compliance_domain": "cross_border_transfer",
         "content": "处理100万人以上个人信息的数据处理者向境外提供个人信息，或累计向境外提供10万人以上个人信息或1万人以上敏感个人信息的，应申报安全评估。"},
        {"id": "CCPA-1798.100", "regulation_id": "CCPA", "article_number": "§1798.100",
         "title": "消费者知情权", "risk_level": "high", "compliance_domain": "data_privacy",
         "content": "消费者有权要求企业披露其收集的个人信息类别和具体内容。"},
    ]

    redlines = [
        {"id": "RL-001", "title": "最小必要原则 — 禁止过度收集",
         "description": "任何业务场景下，个人信息收集不得超出实现处理目的的最小必要范围。每项收集必须有明确的法律依据和业务必要性说明。",
         "remediation": "审查数据处理清单，删除非必要字段；在隐私政策中逐项说明收集目的。",
         "priority": "critical", "compliance_domain": "data_privacy",
         "related_clause_ids": ["GDPR-Art5-1-c", "PIPL-Art13"]},
        {"id": "RL-002", "title": "单独同意 — 不得一揽子获取同意",
         "description": "敏感个人信息处理、跨境传输、向第三方提供等场景，必须取得个人的单独同意，不得与其他授权捆绑。",
         "remediation": "拆分同意项，设计独立勾选框；提供撤回同意的便捷途径。",
         "priority": "critical", "compliance_domain": "data_privacy",
         "related_clause_ids": ["PIPL-Art13"]},
        {"id": "RL-003", "title": "数据出境安全评估 — 未通过不得出境",
         "description": "触发安全评估门槛的出境场景，必须在通过国家网信部门安全评估后方可向境外提供数据。",
         "remediation": "立即暂停相关数据出境，准备安全评估申报材料；评估替代方案。",
         "priority": "critical", "compliance_domain": "cross_border_transfer",
         "related_clause_ids": ["PIPL-Art38", "DSEA-Art4"]},
        {"id": "RL-004", "title": "AI决策透明度 — 自动化决策可解释",
         "description": "使用AI系统做出的对个人权益有重大影响的自动化决策，必须能够向受影响个人提供有意义的解释。",
         "remediation": "部署可解释性模块，建立人工复核通道，在产品界面披露AI决策逻辑。",
         "priority": "high", "compliance_domain": "ai_governance",
         "related_clause_ids": []},
        {"id": "RL-005", "title": "数据主体权利响应 — 30日内处理",
         "description": "个人行使查阅、更正、删除、限制处理等权利时，必须在30日内给予答复。",
         "remediation": "建立DSAR处理流程，部署数据检索工具，制定响应模板。",
         "priority": "high", "compliance_domain": "data_privacy",
         "related_clause_ids": ["GDPR-Art17"]},
    ]

    kb.import_from_dict(regulations, clauses, redlines)
    return kb.get_stats()


if __name__ == "__main__":
    stats = migrate_seed_data()
    print(f"知识库初始化完成: {stats}")
