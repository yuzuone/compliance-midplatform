"""
PII 实体识别与脱敏引擎 — "脑手分离"架构的安全边界核心。

设计原则：
  1. 纯本地运行，不依赖任何外部 API（零数据外泄风险）
  2. 支持中文 PII 实体识别（姓名、身份证、电话、邮箱、地址、公司名、银行卡号）
  3. 可插拔架构：正则引擎 + 可选的 Presidio/ spaCy 增强

脱敏策略：
  - mask:    张三 → 张*  (部分遮盖，保留格式感)
  - replace: 张三 → PERSON_001 (伪名替换，可反向映射)
  - redact:  张三 → ████ (完全遮盖)
"""

import re
import hashlib
import logging
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger(__name__)


# ─── PII 正则模式库（中文场景） ────────────────────────────────

PII_PATTERNS: list[tuple[str, str, re.Pattern]] = [
    # (实体类型, 描述, 正则)
    ("ID_CARD", "中国居民身份证（18位）",
     re.compile(r'(?<!\d)[1-9]\d{5}(?:19|20)\d{2}(?:0[1-9]|1[0-2])(?:0[1-9]|[12]\d|3[01])\d{3}[\dXx](?!\d)')),

    ("PHONE", "中国大陆手机号",
     re.compile(r'(?<!\d)1[3-9]\d{9}(?!\d)')),

    ("PHONE", "中国大陆座机号",
     re.compile(r'(?<!\d)(?:0\d{2,3}-?)?[1-9]\d{6,7}(?!\d)')),

    ("EMAIL", "电子邮箱",
     re.compile(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}')),

    ("BANK_CARD", "银行卡号（16-19位）",
     re.compile(r'(?<!\d)\d{16,19}(?!\d)')),

    ("ADDRESS", "详细地址（含省市区+具体地址）",
     re.compile(
         r'(?:北京|上海|天津|重庆|河北|山西|辽宁|吉林|黑龙江|江苏|浙江|安徽|福建|江西|山东|河南|湖北|湖南|广东|'
         r'海南|四川|贵州|云南|陕西|甘肃|青海|台湾|内蒙古|广西|西藏|宁夏|新疆|香港|澳门)'
         r'(?:省|市|自治区|特别行政区)?'
         r'(?:[^\n]{2,50}?(?:路|街|巷|道|弄|号|楼|室|层|座|栋|单元|小区|大厦|广场|中心|园区))'
     )),

    ("COMPANY", "公司/企业名称",
     re.compile(
         r'(?:[\u4e00-\u9fa5a-zA-Z]{2,30})'
         r'(?:有限(?:责任)?公司|股份有限(?:责任)?公司|集团(?:有限)?公司'
         r'|有限公司|集团公司|责任公司|合伙(?:企业)?|事务所'
         r'|厂|店|中心|部|社|院|所|处|馆|行)'
     )),

    ("NAME", "中文姓名（2-4字，含常见百家姓）",
     re.compile(
         r'(?:[李王张刘陈杨赵黄周吴徐孙胡朱高林何郭马罗梁宋郑谢韩唐冯于董萧程曹袁邓许傅沈曾彭吕苏卢蒋蔡贾丁魏薛叶阎余潘杜戴夏钟汪田任姜范方石姚谭廖邹熊金陆郝孔白崔康毛邱秦江史顾侯邵孟龙万段雷钱汤尹黎易常武乔贺赖龚文]'
         r')[\u4e00-\u9fa5]{1,3}'
         r'(?!(?:有限|股份|集团|公司|厂|店|中心|部|社|院|所|处|馆|行|路|街|巷|道|弄|号|楼|室|层|座|栋|单元|小区|大厦|广场|中心|园区))'
     )),
]


def _luhn_check(card_number: str) -> bool:
    """Luhn 算法校验银行卡号，减少误报"""
    digits = [int(d) for d in card_number]
    checksum = 0
    for i, d in enumerate(reversed(digits)):
        if i % 2 == 0:
            checksum += d
        else:
            doubled = d * 2
            checksum += doubled if doubled < 10 else doubled - 9
    return checksum % 10 == 0


# ─── 脱敏函数 ──────────────────────────────────────────────────

def mask_text(text: str, entity_type: str) -> str:
    """部分遮盖 — 张三 → 张*  |  13800138000 → 138****8000"""
    if entity_type == "NAME":
        return text[0] + "*" * (len(text) - 1) if len(text) >= 2 else "*"
    elif entity_type in ("PHONE",):
        return text[:3] + "****" + text[-4:] if len(text) >= 11 else "****"
    elif entity_type == "EMAIL":
        parts = text.split("@")
        local = parts[0][:2] + "***" if len(parts[0]) > 2 else "***"
        return f"{local}@{parts[1]}" if len(parts) > 1 else "***@***"
    elif entity_type == "ID_CARD":
        return text[:6] + "********" + text[-4:] if len(text) >= 18 else "****"
    elif entity_type == "ADDRESS":
        # 保留省市区，遮盖具体地址
        match = re.match(r'^([\u4e00-\u9fa5]{2,9}(?:省|市|区|县))(.+)$', text)
        if match:
            return match.group(1) + "****"
        return "****"
    elif entity_type == "COMPANY":
        return text[:3] + "****" if len(text) > 3 else "****"
    else:
        half = max(len(text) // 3, 1)
        return text[:half] + "*" * (len(text) - half * 2) + text[-half:] if len(text) > 4 else "****"


class PIIMapStore:
    """
    PII 映射存储 — 存储脱敏前后的映射关系，用于审查完成后还原。
    生产环境应替换为加密数据库存储。
    """

    def __init__(self):
        self._store: dict[str, dict] = {}

    def register(self, original: str, entity_type: str, replacement: str) -> str:
        """注册一个映射，返回唯一键"""
        key = hashlib.sha256(f"{original}:{entity_type}".encode()).hexdigest()[:12]
        self._store[key] = {
            "original": original,
            "entity_type": entity_type,
            "replacement": replacement,
        }
        return key

    def lookup(self, key: str) -> Optional[dict]:
        """根据键查找原始值"""
        return self._store.get(key)

    def restore(self, text: str) -> str:
        """将文本中的替换标记还原为原始值"""
        for key, entry in self._store.items():
            text = text.replace(entry["replacement"], entry["original"])
        return text


# ─── 核心引擎 ──────────────────────────────────────────────────

@dataclass
class PIIEntity:
    """PII 实体识别结果"""
    entity_type: str
    original_text: str
    masked_text: str
    start_pos: int
    end_pos: int
    confidence: float
    map_key: str = ""


@dataclass
class DesensitizeResult:
    """脱敏结果"""
    original_content: str
    desensitized_content: str
    entities: list[PIIEntity]
    strategy: str
    entity_count: int


class PIIEngine:
    """
    PII 识别与脱敏引擎。

    使用方式:
        engine = PIIEngine(strategy="mask")
        result = engine.desensitize("张三的联系方式是13800138000")
        print(result.desensitized_content)  # "张*的联系方式是138****8000"
        restored = engine.pii_map.restore(result.desensitized_content)
    """

    def __init__(self, strategy: str = "mask", map_store: Optional[PIIMapStore] = None):
        self.strategy = strategy
        self.pii_map = map_store or PIIMapStore()
        self._entity_counter: dict[str, int] = {}

    def desensitize(self, content: str, entity_types: Optional[list[str]] = None) -> DesensitizeResult:
        """
        对文本内容进行 PII 实体识别和脱敏。

        Args:
            content: 原始文本内容
            entity_types: 要识别的实体类型列表，None 表示全部

        Returns:
            DesensitizeResult 包含脱敏后的内容和实体列表
        """
        entities: list[PIIEntity] = []
        occupied_spans: list[tuple[int, int]] = []  # 已占用的位置区间

        for entity_type, description, pattern in PII_PATTERNS:
            if entity_types and entity_type not in entity_types:
                continue

            for match in pattern.finditer(content):
                start, end = match.start(), match.end()
                original = match.group()

                # 银行卡号额外 Luhn 校验，减少误报
                if entity_type == "BANK_CARD" and not _luhn_check(original):
                    continue

                # 避免重叠匹配（如身份证内的日期匹配到其他模式）
                if any(occ_start < end and occ_end > start for occ_start, occ_end in occupied_spans):
                    continue

                masked = self._apply_strategy(original, entity_type)
                occupied_spans.append((start, end))

                entity = PIIEntity(
                    entity_type=entity_type,
                    original_text=original,
                    masked_text=masked,
                    start_pos=start,
                    end_pos=end,
                    confidence=self._confidence(entity_type),
                    map_key=self.pii_map.register(original, entity_type, masked),
                )
                entities.append(entity)

        # 构造脱敏后的文本（从后往前替换，保持位置正确）
        desensitized = content
        for entity in sorted(entities, key=lambda e: e.start_pos, reverse=True):
            desensitized = (
                desensitized[: entity.start_pos]
                + entity.masked_text
                + desensitized[entity.end_pos :]
            )

        return DesensitizeResult(
            original_content=content,
            desensitized_content=desensitized,
            entities=entities,
            strategy=self.strategy,
            entity_count=len(entities),
        )

    def _apply_strategy(self, text: str, entity_type: str) -> str:
        """根据策略对识别到的实体进行脱敏处理"""
        if self.strategy == "redact":
            return "█" * min(len(text), 10)

        if self.strategy == "replace":
            # 伪名替换: PERSON_001, PHONE_001
            counter_key = f"{entity_type}_counter"
            if counter_key not in self._entity_counter:
                self._entity_counter[counter_key] = 0
            self._entity_counter[counter_key] += 1
            return f"<{entity_type}_{self._entity_counter[counter_key]:03d}>"

        # 默认 mask
        return mask_text(text, entity_type)

    @staticmethod
    def _confidence(entity_type: str) -> float:
        """不同实体类型的识别置信度"""
        confidences = {
            "ID_CARD": 0.95,
            "PHONE": 0.92,
            "EMAIL": 0.98,
            "BANK_CARD": 0.85,
            "ADDRESS": 0.75,
            "COMPANY": 0.78,
            "NAME": 0.72,
        }
        return confidences.get(entity_type, 0.70)
