"""
Word 文档红线批注引擎 — "脑手分离"中的"手"。

设计原则：
  1. 只接收结构化的 DocumentAnnotation 指令，不接收自由文本
  2. 操作原文档生成带批注的修订版，原文档不修改
  3. 支持修订模式（Track Changes 模拟）: delete/insert/replace/comment/highlight

python-docx 限制说明:
  python-docx 不直接支持 Word 原生的"修订模式"(Track Changes)。
  替代方案:
  - delete: 给删除文本加红色删除线
  - insert: 蓝色下划线标注新增文本
  - replace: 红色删除线原文 + 蓝色下划线新文
  - comment: Word 原生批注（python-docx 有限支持）
  - highlight: 黄色高亮背景
"""

import logging
import os
from datetime import datetime
from typing import Optional
from dataclasses import dataclass

from docx import Document
from docx.shared import Pt, RGBColor, Inches, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn, nsdecls
from docx.oxml import parse_xml

logger = logging.getLogger(__name__)


# ─── 颜色常量 ──────────────────────────────────────────────────

RED = RGBColor(0xFF, 0x00, 0x00)       # 删除标记
BLUE = RGBColor(0x00, 0x66, 0xCC)      # 新增标记
YELLOW = RGBColor(0xFF, 0xFF, 0x00)    # 高亮背景
GRAY = RGBColor(0x80, 0x80, 0x80)      # 说明文字
DARK_RED = RGBColor(0xCC, 0x00, 0x00)  # Critical 标记
ORANGE = RGBColor(0xFF, 0x8C, 0x00)    # High 标记


SEVERITY_COLORS = {
    "critical": DARK_RED,
    "high": ORANGE,
    "medium": RGBColor(0xCC, 0xAA, 0x00),
    "low": RGBColor(0x00, 0x80, 0x00),
    "info": GRAY,
}


@dataclass
class AnnotationInstruction:
    """单条批注指令（来自合规智能体）"""
    annotation_type: str  # delete | insert | replace | comment | highlight
    paragraph_index: int = 0
    start_char: int = 0
    end_char: int = 0
    original_text: str = ""
    suggested_text: str = ""
    comment_text: str = ""
    highlight_color: str = "FF0000"
    severity: str = "info"
    playbook_ref: str = ""


class WordRedlineEngine:
    """
    Word 文档红线批注引擎。

    使用方式:
        engine = WordRedlineEngine()
        instructions = [
            AnnotationInstruction(annotation_type="delete", original_text="违规条款..."),
            AnnotationInstruction(annotation_type="insert", suggested_text="合规替代方案..."),
        ]
        engine.render("input.docx", instructions, "output_redlined.docx")
    """

    def render(
        self,
        template_path: str,
        instructions: list[AnnotationInstruction],
        output_path: Optional[str] = None,
        add_cover_page: bool = True,
    ) -> str:
        """
        对模板文档应用红线批注，生成修订版文档。

        Args:
            template_path: 原始文档路径
            instructions: 批注指令列表
            output_path: 输出路径，None 则自动生成
            add_cover_page: 是否添加审查摘要封面页

        Returns:
            输出文件路径
        """
        if not os.path.exists(template_path):
            raise FileNotFoundError(f"模板文件不存在: {template_path}")

        # 读取原文档
        doc = Document(template_path)

        # 添加审查封面页
        if add_cover_page:
            self._add_cover_page(doc, instructions)

        # 应用批注指令
        for i, inst in enumerate(instructions):
            try:
                self._apply_annotation(doc, inst, i + 1)
            except Exception as e:
                logger.warning(
                    "annotation_failed",
                    index=i,
                    type=inst.annotation_type,
                    error=str(e),
                )

        # 添加审查汇总页
        self._add_summary_page(doc, instructions)

        # 保存输出
        if output_path is None:
            base, ext = os.path.splitext(template_path)
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_path = f"{base}_红线批注_{timestamp}{ext}"

        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
        doc.save(output_path)
        logger.info("render_complete output=%s annotations=%d", output_path, len(instructions))

        return output_path

    # ─── 封面页 ─────────────────────────────────────────────────

    def _add_cover_page(self, doc: Document, instructions: list[AnnotationInstruction]):
        """在文档最前面添加审查意见书封面"""
        first_paragraph = doc.paragraphs[0]

        # 标题
        p = first_paragraph.insert_paragraph_before()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run("数据合规审查意见书")
        run.bold = True
        run.font.size = Pt(24)
        run.font.color.rgb = DARK_RED

        # 机密标记
        p = first_paragraph.insert_paragraph_before()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run("CONFIDENTIAL — 仅供内部合规审查使用")
        run.font.size = Pt(10)
        run.font.color.rgb = RED
        run.italic = True

        # 生成信息
        p = first_paragraph.insert_paragraph_before()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run(f"生成日期: {datetime.now().strftime('%Y年%m月%d日')}")
        run.font.size = Pt(11)
        run.font.color.rgb = GRAY

        p = first_paragraph.insert_paragraph_before()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run("审查引擎: 零信任合规审查中台 v2.0")
        run.font.size = Pt(10)
        run.font.color.rgb = GRAY

        p = first_paragraph.insert_paragraph_before()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run(f"审查范围: 数据隐私 / 个人信息保护 / 跨境数据传输 / AI治理")
        run.font.size = Pt(10)
        run.font.color.rgb = GRAY

        # 审查摘要
        critical_count = sum(1 for i in instructions if i.severity == "critical")
        high_count = sum(1 for i in instructions if i.severity == "high")
        total_count = len(instructions)

        p = first_paragraph.insert_paragraph_before()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run(f"共发现 {total_count} 项审查意见，其中红线事项 {critical_count} 项，高风险事项 {high_count} 项")
        run.font.size = Pt(12)
        run.font.color.rgb = DARK_RED
        run.bold = True

        # 分隔线
        p = first_paragraph.insert_paragraph_before()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run("─" * 50)
        run.font.color.rgb = GRAY

        # 免责声明
        p = first_paragraph.insert_paragraph_before()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run("【重要提示】")
        run.bold = True
        run.font.size = Pt(10)
        run.font.color.rgb = DARK_RED

        p = first_paragraph.insert_paragraph_before()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run("本意见书由AI合规审查引擎自动生成，仅供参考。所引用的法律条文可能不完整或已更新。")
        run.font.size = Pt(9)
        run.font.color.rgb = GRAY

        p = first_paragraph.insert_paragraph_before()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run("最终合规决策应由具备执业资质的法律顾问在审阅完整合同文本后作出。")
        run.font.size = Pt(9)
        run.font.color.rgb = GRAY

        # 换页
        p = first_paragraph.insert_paragraph_before()
        run = p.add_run()
        run._element.append(parse_xml(f'<w:br {nsdecls("w")} w:type="page"/>'))

    # ─── 批注应用 ───────────────────────────────────────────────

    def _apply_annotation(self, doc: Document, inst: AnnotationInstruction, index: int):
        """根据类型将单条批注应用到文档"""

        if inst.annotation_type == "comment":
            self._add_paragraph_comment(doc, inst, index)

        elif inst.annotation_type == "highlight":
            self._add_text_highlight(doc, inst, index)

        elif inst.annotation_type == "replace":
            self._apply_replace(doc, inst, index)

        elif inst.annotation_type == "delete":
            self._apply_delete(doc, inst, index)

        elif inst.annotation_type == "insert":
            self._apply_insert(doc, inst, index)

    # ─── 删除操作 ───────────────────────────────────────────────

    def _apply_delete(self, doc: Document, inst: AnnotationInstruction, index: int):
        """红线删除: 红色删除线 + 批注框"""
        p = doc.add_paragraph()
        self._add_severity_label(p, inst, index)

        # 原文展示（红色删除线）
        run = p.add_run("【建议删除】: ")
        run.bold = True
        run.font.size = Pt(10)

        if inst.original_text:
            run = p.add_run(inst.original_text)
            run.font.color.rgb = RED
            run.font.strike = True
            run.font.size = Pt(10)

        # 理由
        if inst.comment_text:
            p2 = doc.add_paragraph()
            run = p2.add_run(f"  理由: {inst.comment_text}")
            run.font.size = Pt(9)
            run.font.color.rgb = GRAY
            run.italic = True

        if inst.playbook_ref:
            run = p2.add_run(f"  (参考: {inst.playbook_ref})")
            run.font.size = Pt(8)
            run.font.color.rgb = GRAY

    # ─── 插入操作 ───────────────────────────────────────────────

    def _apply_insert(self, doc: Document, inst: AnnotationInstruction, index: int):
        """蓝色下划线插入标注"""
        p = doc.add_paragraph()
        self._add_severity_label(p, inst, index)

        run = p.add_run("【建议新增】: ")
        run.bold = True
        run.font.size = Pt(10)

        if inst.suggested_text:
            run = p.add_run(inst.suggested_text)
            run.font.color.rgb = BLUE
            run.underline = True
            run.font.size = Pt(10)

        if inst.comment_text:
            p2 = doc.add_paragraph()
            run = p2.add_run(f"  说明: {inst.comment_text}")
            run.font.size = Pt(9)
            run.font.color.rgb = GRAY
            run.italic = True

    # ─── 替换操作 ───────────────────────────────────────────────

    def _apply_replace(self, doc: Document, inst: AnnotationInstruction, index: int):
        """替换: 红色删除线原文 + 箭头 + 蓝色下划线新文本"""
        p = doc.add_paragraph()
        self._add_severity_label(p, inst, index)

        run = p.add_run("【建议修改】: ")
        run.bold = True
        run.font.size = Pt(10)

        if inst.original_text:
            run = p.add_run(inst.original_text)
            run.font.color.rgb = RED
            run.font.strike = True
            run.font.size = Pt(10)

        run = p.add_run("  →  ")
        run.font.size = Pt(10)

        if inst.suggested_text:
            run = p.add_run(inst.suggested_text)
            run.font.color.rgb = BLUE
            run.underline = True
            run.font.size = Pt(10)
            run.bold = True

        if inst.comment_text:
            p2 = doc.add_paragraph()
            run = p2.add_run(f"  说明: {inst.comment_text}")
            run.font.size = Pt(9)
            run.font.color.rgb = GRAY
            run.italic = True

    # ─── 批注操作 ───────────────────────────────────────────────

    def _add_paragraph_comment(self, doc: Document, inst: AnnotationInstruction, index: int):
        """审查意见书格式: 标题 / 风险等级 / 法律依据 / 分析 / 修改建议"""
        # 意见编号 + 风险等级标签
        p = doc.add_paragraph()
        self._add_severity_label(p, inst, index)

        # 标题（如果 comment_text 包含标题）
        if inst.comment_text:
            # comment_text 可能包含多行，第一行可能是标题
            lines = inst.comment_text.strip().split('，', 1)
            if len(lines) > 1:
                title = lines[0] + '，'
                body = lines[1]
            else:
                title = ''
                body = inst.comment_text

            if title:
                run = p.add_run(title)
                run.bold = True
                run.font.size = Pt(12)
                run.font.color.rgb = DARK_RED

            p2 = doc.add_paragraph()
            run = p2.add_run(body)
            run.font.size = Pt(10.5)
            run.font.color.rgb = GRAY
            p2.paragraph_format.space_after = Pt(2)

        # 法律依据
        if inst.playbook_ref:
            p3 = doc.add_paragraph()
            run = p3.add_run(f"【法律依据】{inst.playbook_ref}")
            run.font.size = Pt(9.5)
            run.font.color.rgb = ORANGE
            run.italic = True

        # 修改建议
        if inst.suggested_text:
            p4 = doc.add_paragraph()
            run = p4.add_run(f"【修改建议】{inst.suggested_text}")
            run.font.size = Pt(10)
            run.font.color.rgb = BLUE

        # 分隔
        p5 = doc.add_paragraph()
        run = p5.add_run("─" * 40)
        run.font.size = Pt(8)
        run.font.color.rgb = GRAY

    # ─── 高亮操作 ───────────────────────────────────────────────

    def _add_text_highlight(self, doc: Document, inst: AnnotationInstruction, index: int):
        """黄色背景高亮 + 批注"""
        p = doc.add_paragraph()
        self._add_severity_label(p, inst, index)

        run = p.add_run("【高亮标记】: ")
        run.bold = True
        run.font.size = Pt(10)

        if inst.original_text:
            run = p.add_run(inst.original_text)
            # 使用 shading 实现高亮背景
            shading = parse_xml(
                f'<w:shd {nsdecls("w")} w:fill="FFFF00" w:val="clear"/>'
            )
            run._element.rPr.append(shading)
            run.font.size = Pt(10)

        if inst.comment_text:
            run = p.add_run(f"  — {inst.comment_text}")
            run.font.size = Pt(9)
            run.font.color.rgb = GRAY

    # ─── 辅助方法 ───────────────────────────────────────────────

    def _add_severity_label(self, paragraph, inst: AnnotationInstruction, index: int):
        """添加严重程度标签"""
        run = paragraph.add_run(f"[{inst.severity.upper()}] ")
        run.bold = True
        run.font.size = Pt(9)
        run.font.color.rgb = SEVERITY_COLORS.get(inst.severity, GRAY)

        run = paragraph.add_run(f"#{index} ")
        run.font.size = Pt(9)
        run.font.color.rgb = GRAY

    def _add_summary_page(self, doc: Document, instructions: list[AnnotationInstruction]):
        """在文档末尾添加审查汇总"""
        doc.add_page_break()

        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run("审查汇总")
        run.bold = True
        run.font.size = Pt(18)
        run.font.color.rgb = DARK_RED

        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run("─" * 50)
        run.font.color.rgb = GRAY

        # 统计
        from collections import Counter
        type_counts = Counter(i.annotation_type for i in instructions)
        sev_counts = Counter(i.severity for i in instructions)

        p = doc.add_paragraph()
        run = p.add_run("操作统计:")
        run.bold = True
        for op_type, count in type_counts.most_common():
            p = doc.add_paragraph()
            run = p.add_run(f"  {op_type}: {count} 处")
            run.font.size = Pt(10)

        p = doc.add_paragraph()
        run = p.add_run("严重程度分布:")
        run.bold = True
        for sev, count in sev_counts.most_common():
            p = doc.add_paragraph()
            run = p.add_run(f"  {sev}: {count} 项")
            run.font.size = Pt(10)
            run.font.color.rgb = SEVERITY_COLORS.get(sev, GRAY)

        # 免责声明
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run("\n本报告由零信任合规审查中台自动生成，仅供内部参考。")
        run.font.size = Pt(8)
        run.font.color.rgb = GRAY
        run.italic = True
        run = p.add_run("\n最终合规决策应由具备资质的法律顾问确认。")
        run.font.size = Pt(8)
        run.font.color.rgb = GRAY
        run.italic = True
