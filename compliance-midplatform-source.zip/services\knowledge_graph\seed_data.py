"""
合规知识图谱 — 种子数据

包含 GDPR、PIPL、CCPA 法规条款、企业红线条款 Playbook 和审查案例。
数据覆盖三个核心合规领域: data_privacy, cross_border_transfer, ai_governance
"""

import logging
from services.knowledge_graph.schema import Neo4jConnection

logger = logging.getLogger(__name__)

# ─── 种子数据 Cypher ──────────────────────────────────────────────

SEED_DATA_CYPHER = """
// ==========================================
// 1. 合规领域
// ==========================================
MERGE (d1:ComplianceDomain {name: 'data_privacy'})
SET d1.label_cn = '数据隐私',
    d1.description = '个人数据处理、存储、跨境传输的合规要求'

MERGE (d2:ComplianceDomain {name: 'cross_border_transfer'})
SET d2.label_cn = '跨境数据传输',
    d2.description = '数据出境安全评估、标准合同、认证等合规路径'

MERGE (d3:ComplianceDomain {name: 'ai_governance'})
SET d3.label_cn = 'AI 治理',
    d3.description = '人工智能系统的透明度、公平性、可解释性合规'

MERGE (d4:ComplianceDomain {name: 'export_control'})
SET d4.label_cn = '出口管制',
    d4.description = '技术出口、加密算法、两用物项等出口管制合规'

// ==========================================
// 2. 法规
// ==========================================
MERGE (r1:Regulation {name: 'GDPR'})
SET r1.full_name = 'General Data Protection Regulation',
    r1.jurisdiction = 'EU',
    r1.effective_date = '2018-05-25'

MERGE (r2:Regulation {name: 'PIPL'})
SET r2.full_name = '中华人民共和国个人信息保护法',
    r2.jurisdiction = 'China',
    r2.effective_date = '2021-11-01'

MERGE (r3:Regulation {name: 'CCPA'})
SET r3.full_name = 'California Consumer Privacy Act',
    r3.jurisdiction = 'US-CA',
    r3.effective_date = '2020-01-01'

MERGE (r4:Regulation {name: '数据出境安全评估办法'})
SET r4.full_name = '数据出境安全评估办法',
    r4.jurisdiction = 'China',
    r4.effective_date = '2022-09-01'

MERGE (r5:Regulation {name: 'EU AI Act'})
SET r5.full_name = 'EU Artificial Intelligence Act',
    r5.jurisdiction = 'EU',
    r5.effective_date = '2024-08-01'

// ==========================================
// 3. 法规条款
// ==========================================
// GDPR 条款
MERGE (c1:Clause {clause_id: 'GDPR-Art5-1-c'})
SET c1.title = '数据最小化原则',
    c1.content = '个人数据应充分、相关且限于处理目的所必需的范围。',
    c1.risk_level = 'critical'

MERGE (c2:Clause {clause_id: 'GDPR-Art44'})
SET c2.title = '跨境数据传输原则',
    c2.content = '正在进行或将进行处理的个人数据转移到第三国或国际组织，控制者和处理者应遵守本章规定的条件。',
    c2.risk_level = 'critical'

MERGE (c3:Clause {clause_id: 'GDPR-Art17'})
SET c3.title = '删除权（被遗忘权）',
    c3.content = '数据主体有权要求控制者无不当延误地删除与其相关的个人数据。',
    c3.risk_level = 'high'

// PIPL 条款
MERGE (c4:Clause {clause_id: 'PIPL-Art13'})
SET c4.title = '个人信息处理告知同意',
    c4.content = '个人信息处理者应在处理个人信息前，以显著方式、清晰易懂的语言向个人告知相关事项并取得同意。',
    c4.risk_level = 'critical'

MERGE (c5:Clause {clause_id: 'PIPL-Art38'})
SET c5.title = '数据出境安全评估',
    c5.content = '个人信息处理者因业务需要确需向境外提供个人信息的，应通过国家网信部门组织的安全评估。',
    c5.risk_level = 'critical'

MERGE (c6:Clause {clause_id: 'PIPL-Art55'})
SET c6.title = '个人信息保护影响评估',
    c6.content = '处理敏感个人信息、委托处理、向境外提供个人信息等情形，应事前进行个人信息保护影响评估。',
    c6.risk_level = 'high'

// CCPA 条款
MERGE (c7:Clause {clause_id: 'CCPA-1798.100'})
SET c7.title = '消费者知情权',
    c7.content = '消费者有权要求企业披露其收集的个人信息类别和具体内容。',
    c7.risk_level = 'high'

MERGE (c8:Clause {clause_id: 'CCPA-1798.105'})
SET c8.title = '消费者删除权',
    c8.content = '消费者有权要求企业删除从其收集的个人信息。',
    c8.risk_level = 'high'

// 数据出境安全评估办法
MERGE (c9:Clause {clause_id: 'DSEA-Art4'})
SET c9.title = '安全评估触发条件',
    c9.content = '处理100万人以上个人信息的数据处理者向境外提供个人信息，或自上年1月1日起累计向境外提供10万人以上个人信息或1万人以上敏感个人信息的，应申报安全评估。',
    c9.risk_level = 'critical'

MERGE (c10:Clause {clause_id: 'DSEA-Art8'})
SET c10.title = '安全评估重点内容',
    c10.content = '评估包括数据出境目的、范围、方式合法性，境外接收方数据保护能力，数据安全风险等六方面。',
    c10.risk_level = 'high'

// EU AI Act
MERGE (c11:Clause {clause_id: 'EU_AI_Act-Art5'})
SET c11.title = '禁止的AI实践',
    c11.content = '禁止投放、投入使用或使用通过潜意识技术扭曲个人行为、利用弱势群体脆弱性、政府社会评分等AI系统。',
    c11.risk_level = 'critical'

MERGE (c12:Clause {clause_id: 'EU_AI_Act-Art13'})
SET c12.title = '透明度与提供信息',
    c12.content = '高风险AI系统的设计和开发应确保其运行足够透明，以便部署者理解和使用。',
    c12.risk_level = 'high'

// ==========================================
// 4. 关联: 法规 → 条款
// ==========================================
MATCH (r:Regulation {name: 'GDPR'}), (c:Clause {clause_id: 'GDPR-Art5-1-c'}) MERGE (r)-[:CONTAINS]->(c);
MATCH (r:Regulation {name: 'GDPR'}), (c:Clause {clause_id: 'GDPR-Art44'}) MERGE (r)-[:CONTAINS]->(c);
MATCH (r:Regulation {name: 'GDPR'}), (c:Clause {clause_id: 'GDPR-Art17'}) MERGE (r)-[:CONTAINS]->(c);
MATCH (r:Regulation {name: 'PIPL'}), (c:Clause {clause_id: 'PIPL-Art13'}) MERGE (r)-[:CONTAINS]->(c);
MATCH (r:Regulation {name: 'PIPL'}), (c:Clause {clause_id: 'PIPL-Art38'}) MERGE (r)-[:CONTAINS]->(c);
MATCH (r:Regulation {name: 'PIPL'}), (c:Clause {clause_id: 'PIPL-Art55'}) MERGE (r)-[:CONTAINS]->(c);
MATCH (r:Regulation {name: 'CCPA'}), (c:Clause {clause_id: 'CCPA-1798.100'}) MERGE (r)-[:CONTAINS]->(c);
MATCH (r:Regulation {name: 'CCPA'}), (c:Clause {clause_id: 'CCPA-1798.105'}) MERGE (r)-[:CONTAINS]->(c);
MATCH (r:Regulation {name: '数据出境安全评估办法'}), (c:Clause {clause_id: 'DSEA-Art4'}) MERGE (r)-[:CONTAINS]->(c);
MATCH (r:Regulation {name: '数据出境安全评估办法'}), (c:Clause {clause_id: 'DSEA-Art8'}) MERGE (r)-[:CONTAINS]->(c);
MATCH (r:Regulation {name: 'EU AI Act'}), (c:Clause {clause_id: 'EU_AI_Act-Art5'}) MERGE (r)-[:CONTAINS]->(c);
MATCH (r:Regulation {name: 'EU AI Act'}), (c:Clause {clause_id: 'EU_AI_Act-Art13'}) MERGE (r)-[:CONTAINS]->(c);

// ==========================================
// 5. 红线条款（企业 Playbook）
// ==========================================
MERGE (rl1:RedLine {redline_id: 'RL-001'})
SET rl1.title = '最小必要原则 — 禁止过度收集',
    rl1.description = '任何业务场景下，个人信息收集不得超出实现处理目的的最小必要范围。每项收集必须有明确的法律依据和业务必要性说明。',
    rl1.remediation = '审查数据处理清单，删除非必要字段；在隐私政策中逐项说明收集目的。',
    rl1.priority = 'critical'

MERGE (rl2:RedLine {redline_id: 'RL-002'})
SET rl2.title = '单独同意 — 不得一揽子获取同意',
    rl2.description = '敏感个人信息处理、跨境传输、向第三方提供等场景，必须取得个人的单独同意，不得与其他授权捆绑。',
    rl2.remediation = '拆分同意项，设计独立勾选框；提供撤回同意的便捷途径。',
    rl2.priority = 'critical'

MERGE (rl3:RedLine {redline_id: 'RL-003'})
SET rl3.title = '数据出境安全评估 — 未通过不得出境',
    rl3.description = '触发安全评估门槛的出境场景，必须在通过国家网信部门安全评估后方可向境外提供数据。',
    rl3.remediation = '立即暂停相关数据出境，准备安全评估申报材料；评估替代方案（本地化存储/匿名化）。',
    rl3.priority = 'critical'

MERGE (rl4:RedLine {redline_id: 'RL-004'})
SET rl4.title = 'AI决策透明度 — 自动化决策可解释',
    rl4.description = '使用AI系统做出的对个人权益有重大影响的自动化决策，必须能够向受影响个人提供有意义的解释。',
    rl4.remediation = '部署可解释性模块（SHAP/LIME），建立人工复核通道，在产品界面披露AI决策逻辑。',
    rl4.priority = 'high'

MERGE (rl5:RedLine {redline_id: 'RL-005'})
SET rl5.title = '数据主体权利响应 — 30日内处理',
    rl5.description = '个人行使查阅、更正、删除、限制处理等权利时，必须在30日内给予答复，不得设置不合理障碍。',
    rl5.remediation = '建立DSAR（数据主体权利请求）处理流程，部署数据检索工具，制定响应模板。',
    rl5.priority = 'high'

MERGE (rl6:RedLine {redline_id: 'RL-006'})
SET rl6.title = '加密算法出口管制 — 需取得出口许可',
    rl6.description = '使用超过规定强度（如超过56位对称密钥或512位非对称密钥）的加密产品出口，须申请出口许可证。',
    rl6.remediation = '评估产品使用的加密算法强度，必要时申请出口许可或替换为不受管制的算法。',
    rl6.priority = 'high'

// 条款 → 红线
MATCH (c:Clause {clause_id: 'GDPR-Art5-1-c'}), (rl:RedLine {redline_id: 'RL-001'}) MERGE (c)-[:VIOLATES]->(rl);
MATCH (c:Clause {clause_id: 'PIPL-Art13'}), (rl:RedLine {redline_id: 'RL-002'}) MERGE (c)-[:VIOLATES]->(rl);
MATCH (c:Clause {clause_id: 'PIPL-Art38'}), (rl:RedLine {redline_id: 'RL-003'}) MERGE (c)-[:VIOLATES]->(rl);
MATCH (c:Clause {clause_id: 'EU_AI_Act-Art13'}), (rl:RedLine {redline_id: 'RL-004'}) MERGE (c)-[:VIOLATES]->(rl);
MATCH (c:Clause {clause_id: 'GDPR-Art17'}), (rl:RedLine {redline_id: 'RL-005'}) MERGE (c)-[:VIOLATES]->(rl);
MATCH (c:Clause {clause_id: 'EU_AI_Act-Art5'}), (rl:RedLine {redline_id: 'RL-004'}) MERGE (c)-[:VIOLATES]->(rl);

// 红线 → 领域
MATCH (rl:RedLine {redline_id: 'RL-001'}), (d:ComplianceDomain {name: 'data_privacy'}) MERGE (rl)-[:BELONGS_TO]->(d);
MATCH (rl:RedLine {redline_id: 'RL-002'}), (d:ComplianceDomain {name: 'data_privacy'}) MERGE (rl)-[:BELONGS_TO]->(d);
MATCH (rl:RedLine {redline_id: 'RL-003'}), (d:ComplianceDomain {name: 'cross_border_transfer'}) MERGE (rl)-[:BELONGS_TO]->(d);
MATCH (rl:RedLine {redline_id: 'RL-004'}), (d:ComplianceDomain {name: 'ai_governance'}) MERGE (rl)-[:BELONGS_TO]->(d);
MATCH (rl:RedLine {redline_id: 'RL-005'}), (d:ComplianceDomain {name: 'data_privacy'}) MERGE (rl)-[:BELONGS_TO]->(d);
MATCH (rl:RedLine {redline_id: 'RL-006'}), (d:ComplianceDomain {name: 'export_control'}) MERGE (rl)-[:BELONGS_TO]->(d);

// ==========================================
// 6. Playbook（合规手册）
// ==========================================
MERGE (pb1:Playbook {playbook_id: 'PB-001'})
SET pb1.title = '数据处理合规检查清单',
    pb1.content = '1. 是否已识别所有处理活动的法律依据？\n2. 是否已实施数据最小化？\n3. 是否已更新隐私政策？\n4. 是否已进行DPIA？',
    pb1.domain = 'data_privacy'

MERGE (pb2:Playbook {playbook_id: 'PB-002'})
SET pb2.title = '跨境数据传输SOP',
    pb2.content = '1. 识别出境数据类型和量级\n2. 判断是否触发安全评估\n3. 准备自评估报告\n4. 签订标准合同(SCC)\n5. 提交网信办安全评估',
    pb2.domain = 'cross_border_transfer'

MERGE (pb3:Playbook {playbook_id: 'PB-003'})
SET pb3.title = 'AI产品上线合规审查流程',
    pb3.content = '1. AI风险评估分级\n2. 透明度/可解释性验证\n3. 人工复核机制验证\n4. 偏见检测报告\n5. 合规官签字',
    pb3.domain = 'ai_governance'

// Playbook → 红线
MATCH (pb:Playbook {playbook_id: 'PB-001'}), (rl:RedLine {redline_id: 'RL-001'}) MERGE (pb)-[:REFERENCED_BY]->(rl);
MATCH (pb:Playbook {playbook_id: 'PB-001'}), (rl:RedLine {redline_id: 'RL-005'}) MERGE (pb)-[:REFERENCED_BY]->(rl);
MATCH (pb:Playbook {playbook_id: 'PB-002'}), (rl:RedLine {redline_id: 'RL-003'}) MERGE (pb)-[:REFERENCED_BY]->(rl);
MATCH (pb:Playbook {playbook_id: 'PB-003'}), (rl:RedLine {redline_id: 'RL-004'}) MERGE (pb)-[:REFERENCED_BY]->(rl);

// Playbook → 领域
MATCH (pb:Playbook {playbook_id: 'PB-001'}), (d:ComplianceDomain {name: 'data_privacy'}) MERGE (pb)-[:APPLIES_TO]->(d);
MATCH (pb:Playbook {playbook_id: 'PB-002'}), (d:ComplianceDomain {name: 'cross_border_transfer'}) MERGE (pb)-[:APPLIES_TO]->(d);
MATCH (pb:Playbook {playbook_id: 'PB-003'}), (d:ComplianceDomain {name: 'ai_governance'}) MERGE (pb)-[:APPLIES_TO]->(d);

// ==========================================
// 7. 历史审查案例
// ==========================================
MERGE (cse1:ReviewCase {case_id: 'CASE-001'})
SET cse1.title = '某SaaS公司隐私政策审查',
    cse1.summary = '发现隐私政策中个人信息收集范围过宽，未说明每项数据的收集目的。违反最小必要原则。',
    cse1.outcome = '要求缩小收集范围，逐项添加收集目的说明。',
    cse1.severity = 'critical'

MERGE (cse2:ReviewCase {case_id: 'CASE-002'})
SET cse2.title = '某跨境电商平台数据出境审查',
    cse2.summary = '平台累计向境外传输超过10万人次的用户订单数据，未申报安全评估。',
    cse2.outcome = '立即暂停数据出境，启动安全评估申报流程。',
    cse2.severity = 'critical'

MERGE (cse3:ReviewCase {case_id: 'CASE-003'})
SET cse3.title = '某AI招聘系统公平性审查',
    cse3.summary = 'AI招聘系统存在性别偏见，女性候选人通过率显著低于同等资质男性，且决策逻辑不可解释。',
    cse3.outcome = '暂停系统使用，部署偏见检测工具和可解释性模块，建立人工复核流程。',
    cse3.severity = 'high'

// 案例 → 红线
MATCH (cse:ReviewCase {case_id: 'CASE-001'}), (rl:RedLine {redline_id: 'RL-001'}) MERGE (cse)-[:FOUND_VIOLATION]->(rl);
MATCH (cse:ReviewCase {case_id: 'CASE-002'}), (rl:RedLine {redline_id: 'RL-003'}) MERGE (cse)-[:FOUND_VIOLATION]->(rl);
MATCH (cse:ReviewCase {case_id: 'CASE-003'}), (rl:RedLine {redline_id: 'RL-004'}) MERGE (cse)-[:FOUND_VIOLATION]->(rl);
"""


def seed_database(conn: Neo4jConnection) -> None:
    """向 Neo4j 写入种子数据"""
    with conn.session() as session:
        # 分语句执行
        statements = [
            s.strip()
            for s in SEED_DATA_CYPHER.split(";")
            if s.strip() and not s.strip().startswith("//")
        ]
        for i, stmt in enumerate(statements):
            if stmt.startswith("MATCH") or stmt.startswith("MERGE"):
                try:
                    session.run(stmt)
                except Exception as e:
                    logger.warning("seed_error", index=i, error=str(e), statement=stmt[:100])

    # 验证写入
    with conn.session() as session:
        result = session.run(
            """
            MATCH (n)
            RETURN DISTINCT labels(n) AS label, count(n) AS cnt
            """
        )
        counts = {record["label"][0]: record["cnt"] for record in result}
        logger.info("seed_complete", node_counts=counts)
