"""
合规审查中台 — Python SDK

让外部系统（法务系统、合同管理、采购系统）能像调库一样消费中台能力。

使用:
    from compliance_midplatform import ComplianceClient

    client = ComplianceClient(api_key="ct_demo_xxxxx", base_url="http://localhost:8080")

    # 提交审查
    task = client.review("合同文本内容...", domain="data_privacy")

    # 查询结果
    result = client.wait_for_result(task["task_id"])

    # 查询知识库
    clauses = client.search_clauses("数据出境")
    redlines = client.list_redlines("cross_border_transfer")
"""

import time
import json
import urllib.request
import urllib.error
from typing import Optional


class ComplianceClient:
    """合规审查中台 Python SDK 客户端"""

    def __init__(
        self,
        api_key: str,
        base_url: str = "http://localhost:8080",
        timeout: int = 60,
    ):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    def _request(self, method: str, path: str, body: Optional[dict] = None) -> dict:
        url = f"{self.base_url}{path}"
        data = json.dumps(body).encode("utf-8") if body else None
        headers = {
            "Content-Type": "application/json",
            "X-API-Key": self.api_key,
        }

        req = urllib.request.Request(url, data=data, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            error_body = e.read().decode("utf-8") if e.fp else "{}"
            raise ComplianceAPIError(e.code, error_body)
        except urllib.error.URLError as e:
            raise ComplianceAPIError(0, str(e.reason))

    # ─── 审查 ────────────────────────────────────────────

    def review(
        self,
        document_content: str,
        domain: str = "data_privacy",
        pipeline: str = "compliance_review",
    ) -> dict:
        """提交合规审查"""
        return self._request("POST", "/api/review", {
            "document_content": document_content,
            "compliance_domain": domain,
            "pipeline": pipeline,
        })

    def get_task(self, task_id: str) -> dict:
        """查询任务状态"""
        return self._request("GET", f"/api/tasks/{task_id}")

    def wait_for_result(self, task_id: str, poll_interval: float = 2.0, max_wait: float = 120.0) -> dict:
        """轮询等待任务完成"""
        start = time.time()
        while time.time() - start < max_wait:
            task = self.get_task(task_id)
            if task["status"] in ("completed", "failed"):
                return task
            time.sleep(poll_interval)
        raise TimeoutError(f"任务 {task_id} 在 {max_wait}s 内未完成")

    # ─── 知识库 ──────────────────────────────────────────

    def search_clauses(self, query: str) -> dict:
        """搜索法规条款"""
        return self._request("GET", f"/api/knowledge/clauses?q={query}")

    def list_redlines(self, domain: Optional[str] = None) -> dict:
        """查询红线条款"""
        path = f"/api/knowledge/redlines"
        if domain:
            path += f"?domain={domain}"
        return self._request("GET", path)

    def get_knowledge_stats(self) -> dict:
        """知识库统计"""
        return self._request("GET", "/api/knowledge/stats")

    # ─── 租户 ────────────────────────────────────────────

    def whoami(self) -> dict:
        """获取当前租户信息"""
        return self._request("GET", "/api/tenants/me")

    # ─── 健康检查 ────────────────────────────────────────

    def health(self) -> dict:
        """中台健康检查"""
        return self._request("GET", "/health")


class ComplianceAPIError(Exception):
    """中台 API 错误"""

    def __init__(self, status_code: int, body: str):
        self.status_code = status_code
        self.body = body
        super().__init__(f"Compliance API Error {status_code}: {body}")


# ─── Webhook 回调 ──────────────────────────────────────────────

class WebhookManager:
    """事件驱动的 Webhook 回调管理"""

    def __init__(self):
        self._subscriptions: dict[str, list[dict]] = {}

    def subscribe(self, tenant_id: str, event: str, callback_url: str):
        """订阅事件"""
        key = f"{tenant_id}:{event}"
        if key not in self._subscriptions:
            self._subscriptions[key] = []
        self._subscriptions[key].append({
            "callback_url": callback_url,
            "subscribed_at": time.time(),
        })

    def unsubscribe(self, tenant_id: str, event: str, callback_url: str):
        """取消订阅"""
        key = f"{tenant_id}:{event}"
        if key in self._subscriptions:
            self._subscriptions[key] = [
                s for s in self._subscriptions[key]
                if s["callback_url"] != callback_url
            ]

    def publish(self, tenant_id: str, event: str, payload: dict):
        """发布事件到所有订阅者"""
        key = f"{tenant_id}:{event}"
        subscribers = self._subscriptions.get(key, [])

        for sub in subscribers:
            try:
                data = json.dumps({
                    "event": event,
                    "tenant_id": tenant_id,
                    "timestamp": time.time(),
                    "payload": payload,
                }).encode("utf-8")
                req = urllib.request.Request(
                    sub["callback_url"],
                    data=data,
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                urllib.request.urlopen(req, timeout=10)
            except Exception:
                pass  # Webhook 失败不影响主流程


webhook_manager = WebhookManager()


# ─── 使用示例（SDK 自测）───────────────────────────────────────

if __name__ == "__main__":
    print("=== 合规审查中台 SDK 自测 ===\n")

    # 注意: 需要先启动 API Gateway
    client = ComplianceClient(
        api_key="ct_demo_6e3f8a1b2c4d5f7e",  # 从网关日志获取
        base_url="http://localhost:8080",
    )

    try:
        health = client.health()
        print(f"✓ 中台健康: {health['status']}")
    except Exception as e:
        print(f"✗ 中台未启动: {e}")
        print("  请先运行: uvicorn services.api_gateway.main:app --port 8080")

    try:
        kb = client.get_knowledge_stats()
        print(f"✓ 知识库: {kb}")
    except Exception as e:
        print(f"✗ 知识库查询失败: {e}")
