"""
统一服务入口 — 整合 PII 网关 + 静态 Dashboard + 知识图谱 + 文档引擎

开发模式一键启动:
    python app.py

访问:
    http://localhost:8100  — Compliance Dashboard GUI
    http://localhost:8100/pii/api/desensitize — PII 脱敏 API
    http://localhost:8100/pii/health            — PII 网关健康检查
    http://localhost:8100/docs                  — API 文档
"""

import sys
import os

sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

import logging
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse

from shared.config import config
from services.pii_gateway.ner_engine import PIIEngine, PIIMapStore
from services.pii_gateway.models import (
    DesensitizeRequest,
    DesensitizeResponse,
    RestoreRequest,
    RestoreResponse,
    HealthResponse,
    PIIEntityOut,
)

# ─── 日志 ───
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
log = logging.getLogger(__name__)

# ─── 全局状态 ───
pii_map_store = PIIMapStore()
pii_engine = PIIEngine(strategy=config.pii_strategy, map_store=pii_map_store)

# ─── FastAPI 应用 ───
app = FastAPI(
    title="零信任合规审查中台",
    description="Zero Trust Compliance Review Middle Platform — PII 脱敏 + GraphRAG + 红线批注",
    version="2.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ─── 静态文件 (Dashboard GUI) ───
static_dir = os.path.join(os.path.dirname(__file__), "static")
os.makedirs(static_dir, exist_ok=True)


@app.get("/")
async def serve_dashboard():
    """服务 Dashboard GUI"""
    dashboard_path = os.path.join(static_dir, "dashboard.html")
    if os.path.exists(dashboard_path):
        return FileResponse(dashboard_path)
    return {"message": "Dashboard 未找到, 请先构建: python build_dashboard.py"}


# ─── PII 脱敏 API (挂载在 /pii 路径下) ───
@app.get("/pii/health", response_model=HealthResponse)
async def health_check():
    return HealthResponse(status="ok", version="2.0.0", strategy=pii_engine.strategy)


@app.post("/pii/api/desensitize", response_model=DesensitizeResponse)
async def desensitize(request: DesensitizeRequest):
    log.info("desensitize_request content_len=%d", len(request.content))
    try:
        result = pii_engine.desensitize(
            content=request.content,
            entity_types=request.entity_types,
        )
        return DesensitizeResponse(
            desensitized_content=result.desensitized_content,
            entity_count=result.entity_count,
            strategy=result.strategy,
            entities=[
                PIIEntityOut(
                    entity_type=e.entity_type,
                    original_text=e.original_text,
                    masked_text=e.masked_text,
                    start_pos=e.start_pos,
                    end_pos=e.end_pos,
                    confidence=e.confidence,
                    map_key=e.map_key,
                )
                for e in result.entities
            ],
        )
    except Exception as e:
        log.error("desensitize_error: %s", str(e))
        from fastapi import HTTPException

        raise HTTPException(status_code=500, detail=str(e))


@app.post("/pii/api/restore", response_model=RestoreResponse)
async def restore(request: RestoreRequest):
    try:
        restored = pii_map_store.restore(request.content)
        return RestoreResponse(restored_content=restored, restored_count=1)
    except Exception as e:
        from fastapi import HTTPException

        raise HTTPException(status_code=500, detail=str(e))


# ─── 服务状态 ───
@app.get("/api/status")
async def service_status():
    """返回所有微服务的连接状态"""
    import urllib.request

    statuses = {"pii_gateway": "ok", "knowledge_graph": "unknown", "document_engine": "unknown"}

    # 检查知识图谱
    try:
        req = urllib.request.Request(
            f"http://localhost:{config.knowledge_graph_port}/health", method="GET"
        )
        urllib.request.urlopen(req, timeout=2)
        statuses["knowledge_graph"] = "ok"
    except Exception:
        statuses["knowledge_graph"] = "offline"

    # 检查文档引擎
    try:
        req = urllib.request.Request(
            f"http://localhost:{config.document_engine_port}/health", method="GET"
        )
        urllib.request.urlopen(req, timeout=2)
        statuses["document_engine"] = "ok"
    except Exception:
        statuses["document_engine"] = "offline"

    return {"status": "running", "services": statuses}


# ─── 审查报告生成（前端直接下载入口） ─────────────────────────
from pydantic import BaseModel as _BM
from typing import List as _L
from fastapi import UploadFile as _UF, File as _File
import tempfile as _tempfile
import base64 as _b64
import json as _json


class FindingIn(_BM):
    sev: str
    title: str = ""
    detail: str = ""
    desc: str = ""   # backward compat
    law: str = ""
    playbook: str = ""  # backward compat
    type: str = "comment"
    orig: str = ""
    sugg: str = ""


class GenerateReportRequest(_BM):
    findings: _L[FindingIn]
    document_id: str = "未命名文档"
    pii_count: int = 0
    domain: str = "data_privacy"


@app.post("/api/generate-report")
async def generate_report(
    document_id: str = "未命名文档",
    pii_count: int = 0,
    domain: str = "data_privacy",
    findings_json: str = "[]",
    file: _UF = _File(None),
):
    """
    接收审查发现列表 + 可选原始 .docx，生成带批注的 Word 文档。
    如果上传了原始 .docx，批注直接标注在原文上；
    否则生成独立的审查意见书。
    """
    findings = _json.loads(findings_json)
    from services.document_engine.word_renderer import (
        WordRedlineEngine,
        AnnotationInstruction,
    )

    instructions = [
        AnnotationInstruction(
            annotation_type="comment",
            original_text="",
            suggested_text=f.get("sugg", ""),
            comment_text=f"{f.get('title', '合规意见')}，{f.get('detail', f.get('desc', ''))}",
            severity=f.get("sev", "info"),
            playbook_ref=f.get("law", f.get("playbook", "")),
        )
        for f in findings
    ]

    engine = WordRedlineEngine()

    # 如果有上传原始 .docx，用它作为模板；否则生成独立审查意见书
    if file and file.filename:
        raw = await file.read()
        tmp_template = _tempfile.NamedTemporaryFile(suffix=".docx", delete=False)
        template_path = tmp_template.name
        tmp_template.write(raw)
        tmp_template.close()
        add_cover = False  # 原文上标注，不加封面
    else:
        from docx import Document as _Doc
        tmp_template = _tempfile.NamedTemporaryFile(suffix=".docx", delete=False)
        template_path = tmp_template.name
        tmp_template.close()
        tpl = _Doc()
        tpl.add_paragraph("[占位段落 — 此处仅用于确保 python-docx 模板非空]")
        tpl.save(template_path)
        add_cover = True

    try:
        output_path = engine.render(
            template_path=template_path,
            instructions=instructions,
            output_path=None,
            add_cover_page=add_cover,
        )
    finally:
        try:
            os.unlink(template_path)
        except Exception:
            pass

    from fastapi.responses import FileResponse
    return FileResponse(
        output_path,
        media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        filename=os.path.basename(output_path),
    )


# ─── 快速条款入库（前端已完成解析）──────────────────────────

class ClauseData(_BM):
    num: int
    title: str
    body: str
    risk: str = "medium"
    domain: str = "data_privacy"
    raw: str = ""


class SaveClausesRequest(_BM):
    regulation_name: str
    jurisdiction: str = "China"
    effective_date: str = ""
    clauses: _L[ClauseData]


@app.post("/api/knowledge/save-clauses")
async def save_clauses(req: SaveClausesRequest):
    """前端已完成文本解析，后端单连接一气呵成入库"""
    import sqlite3 as _sqlite

    reg_id = f"imported_{_hl.md5(req.regulation_name.encode()).hexdigest()[:8]}"
    db_path = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        "services", "knowledge_base", "knowledge_base.db",
    )
    conn = _sqlite.connect(db_path, timeout=5)
    conn.execute("PRAGMA journal_mode=DELETE")
    conn.execute("PRAGMA synchronous=OFF")  # 极速写入，适合离线导入

    try:
        # 一步：upsert 法规
        conn.execute(
            "INSERT OR REPLACE INTO regulations (id, name, full_name, jurisdiction, effective_date, source_url, source_name) VALUES (?,?,?,?,?,?,?)",
            (reg_id, req.regulation_name, req.regulation_name, req.jurisdiction, req.effective_date, "", "用户导入"),
        )

        # 二步：批量写入条款
        cur = conn.executemany(
            "INSERT OR IGNORE INTO clauses (id, regulation_id, article_number, title, content, risk_level, compliance_domain, status, source_page) VALUES (?,?,?,?,?,?,?,?,?)",
            [
                (f"{reg_id}-Art{c.num}", reg_id, f"Art.{c.num}", c.title, c.body, c.risk, c.domain, "published", f"第{c.raw}条")
                for c in req.clauses
            ],
        )
        conn.commit()
        inserted = cur.rowcount
    finally:
        conn.close()

    return {"status": "ok", "regulation_name": req.regulation_name, "inserted": inserted, "total": len(req.clauses)}


# ─── 文件文本提取（支持 .txt .docx .md）────────────────────────

@app.post("/api/extract-docx")
async def extract_docx_text(file: _UF = _File(...)):
    """
    从上传的文件中提取纯文本。
    支持: .txt .md .docx
    """
    raw = await file.read()
    filename = (file.filename or "").lower()

    if filename.endswith(".docx"):
        from io import BytesIO
        from docx import Document as _Doc

        bio = BytesIO(raw)
        doc = _Doc(bio)
        paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
        text = "\n\n".join(paragraphs)
        return {"text": text, "paragraphs": len(paragraphs), "format": "docx"}
    else:
        # .txt, .md, or unknown — try UTF-8
        try:
            text = raw.decode("utf-8")
        except UnicodeDecodeError:
            try:
                text = raw.decode("gbk")
            except UnicodeDecodeError:
                text = raw.decode("utf-8", errors="replace")
        return {"text": text, "paragraphs": text.count("\n") + 1, "format": "text"}


# ─── 法规导入与自动解析 ─────────────────────────────────────
import re as _re
import hashlib as _hl
from services.knowledge_base.manager import KnowledgeBase  # 模块级导入，避免函数内重复初始化


class RegulationImportRequest(_BM):
    content: str  # 法律条文全文
    regulation_name: str = ""  # 可手动指定名称，空则从文本提取
    jurisdiction: str = "China"  # 管辖区
    source_url: str = ""


@app.post("/api/knowledge/import-regulation")
async def import_regulation(req: RegulationImportRequest):
    """
    导入法律条文并自动解析为结构化条款。

    支持常见中文法律文本格式:
      第X条（标题）正文内容
      第X章 章节名
      第X节 节名

    解析后自动写入知识库（SQLite），返回解析统计。
    """
    kb = KnowledgeBase()

    content = req.content
    name = req.regulation_name

    if not name:
        # 尝试从文本第一行提取名称
        first_line = content.strip().split("\n")[0].strip()
        name = _re.sub(r'[（(].*[）)]', '', first_line).strip()
        if len(name) > 50 or not name:
            name = f"导入法规_{_hl.md5(content[:100].encode()).hexdigest()[:6]}"

    # 生成法规ID
    reg_id = f"imported_{_hl.md5(name.encode()).hexdigest()[:8]}"

    # 提取生效日期
    date_patterns = [
        r'(\d{4})年(\d{1,2})月(\d{1,2})日起施行',
        r'自(\d{4})年(\d{1,2})月(\d{1,2})日起施行',
        r'(?:施行|生效).*?(\d{4})[年.-](\d{1,2})[月.-](\d{1,2})',
    ]
    effective_date = ""
    for pat in date_patterns:
        m = _re.search(pat, content)
        if m:
            try:
                y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
                effective_date = f"{y}-{mo:02d}-{d:02d}"
            except Exception:
                pass
            break

    # 提取最后修改日期
    last_updated = ""
    rev_pat = _re.search(r'(?:修订|修正|修改|更新).*?(\d{4})[年.-](\d{1,2})', content[-200:])
    if rev_pat:
        try:
            last_updated = f"{int(rev_pat.group(1))}-{int(rev_pat.group(2)):02d}"
        except Exception:
            pass

    # 创建/更新法规
    try:
        kb.create_regulation({
            "id": reg_id,
            "name": name,
            "full_name": req.regulation_name or name,
            "jurisdiction": req.jurisdiction,
            "effective_date": effective_date or "",
            "source_url": req.source_url,
            "source_name": "用户导入",
        })
    except Exception:
        pass  # 已存在则跳过

    # 解析条款: 按"第X条"分割文本
    # 先规范化换行（docx提取的内容可能有\n\n），再分割
    normalized = _re.sub(r'\n{2,}', '\n', content)
    article_splitter = _re.compile(r'\n(?=第[零一二三四五六七八九十百千\d]+条)')
    chunks = article_splitter.split(normalized)

    # 提取条款头部: "第X条（标题）"
    article_head = _re.compile(
        r'^第([零一二三四五六七八九十百千\d]+)条\s*[（(]?([^）)\n]{0,60})[）)]?'
    )

    clauses_imported = 0
    errors = []
    batch = []  # 收集所有条款，最后批量插入

    for chunk in chunks:
        m = article_head.match(chunk.strip())
        if not m:
            continue
        try:
            article_num_raw = m.group(1)
            title = m.group(2).strip() if m.group(2) else ""
            body = chunk[m.end():].strip()[:2000]
            article_num = _cn_num_to_int(article_num_raw)
            risk = _infer_risk(title + body)
            domain = _infer_domain(title + body)
            clause_id = f"{reg_id}-Art{article_num}"

            batch.append({
                "id": clause_id,
                "regulation_id": reg_id,
                "article_number": f"Art.{article_num}",
                "title": title,
                "content": body,
                "risk_level": risk,
                "compliance_domain": domain,
                "status": "published",
                "source_page": f"第{article_num_raw}条",
            })
        except Exception as e:
            errors.append({"article": article_num_raw if 'article_num_raw' in dir() else "unknown", "error": str(e)})

    # 批量写入（单连接，一次提交）
    if batch:
        clauses_imported = kb.bulk_create_clauses(batch)

    return {
        "status": "ok",
        "regulation_id": reg_id,
        "regulation_name": name,
        "effective_date": effective_date or "未识别",
        "clauses_imported": clauses_imported,
        "errors": errors,
    }


def _cn_num_to_int(raw: str) -> int:
    """中文数字转整数: 十二->12, 一百二十->120, 二百零八->208, 三百六十五->365, 一千零一->1001"""
    try:
        return int(raw)
    except ValueError:
        pass

    d = {"零": 0, "一": 1, "二": 2, "三": 3, "四": 4, "五": 5, "六": 6, "七": 7, "八": 8, "九": 9}
    m = {"十": 10, "百": 100, "千": 1000, "万": 10000}

    total = 0
    cur = 0  # digit accumulator before a multiplier

    for ch in raw:
        if ch in d:
            cur = d[ch]
        elif ch in m:
            mul = m[ch]
            if cur == 0:
                cur = 1  # bare multiplier: "十" = 10, "百" = 100
            total += cur * mul
            cur = 0
        # "零" is already handled by d["零"]=0, but it should NOT contribute to cur.
        # When "零" is hit, cur becomes 0, which is correct — it resets the digit accumulator.

    # Don't add cur=0 — "零" as the final digit should contribute 0.
    # But "二百零八" → cur=8 after "八" → total=200, add cur=8 → 208. Correct.
    total += cur
    return total if total > 0 else 1


def _infer_risk(text: str) -> str:
    """根据文本关键词推断风险等级"""
    high_risk = r"禁止|不得|必须|应当|吊销|刑事责任|罚款|处罚|安全评估|单独同意|最小必要"
    medium_risk = r"备案|登记|许可|审批|主管部门|监管"
    if _re.search(high_risk, text):
        return "high"
    if _re.search(medium_risk, text):
        return "medium"
    return "medium"


def _infer_domain(text: str) -> str:
    """根据文本关键词推断合规领域"""
    keywords = {
        "data_privacy": r"个人信息|个人数据|隐私|同意|告知|删除权|查阅|数据主体",
        "cross_border_transfer": r"出境|跨境|境外|向境外|第三国|安全评估|标准合同",
        "ai_governance": r"人工智能|AI|算法|自动化决策|画像|推荐|机器学习",
        "export_control": r"出口|技术出口|两用物项|加密|管制",
    }
    for domain, pat in keywords.items():
        if _re.search(pat, text):
            return domain
    return "data_privacy"
if __name__ == "__main__":
    import uvicorn

    port = int(os.environ.get("PORT", "8100"))
    log.info(f"统一服务启动: http://localhost:{port}")
    log.info(f"  Dashboard: http://localhost:{port}/")
    log.info(f"  API 文档:  http://localhost:{port}/docs")

    uvicorn.run(
        "app:app",
        host="0.0.0.0",
        port=port,
        reload=True,
        log_level=config.log_level.lower(),
    )
