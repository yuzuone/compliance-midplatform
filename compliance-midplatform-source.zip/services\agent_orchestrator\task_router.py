"""
任务路由器 — 中台的任务分解与 Agent 调度。

职责:
  1. 任务分解 — 将"合规审查"分解为 [PII脱敏 → GraphRAG → 研判 → 渲染]
  2. Agent 调度 — 为每个步骤匹配最优 Agent
  3. 上下文传递 — 前一步的输出作为后一步的输入
  4. 并行执行 — 独立步骤可并行（如多份文档同时审查）
  5. 失败重试 — 步骤失败时的回退策略
"""

import logging
import json
import asyncio
import httpx
from datetime import datetime, timezone
from typing import Optional

from services.agent_orchestrator.models import (
    AgentType,
    TaskStatus,
    TaskPriority,
    TaskStep,
    OrchestrationTask,
    PipelineDefinition,
    AuditEntry,
    DEFAULT_PIPELINE,
)
from services.agent_orchestrator.agent_registry import AgentRegistry

logger = logging.getLogger(__name__)


class TaskRouter:
    """任务路由器"""

    def __init__(self, registry: AgentRegistry):
        self.registry = registry
        self._active_tasks: dict[str, OrchestrationTask] = {}
        self._task_history: list[OrchestrationTask] = []

    def create_task(
        self,
        tenant_id: str,
        document_content: str,
        compliance_domain: str = "data_privacy",
        pipeline: Optional[PipelineDefinition] = None,
        priority: TaskPriority = TaskPriority.MEDIUM,
        extra_context: Optional[dict] = None,
    ) -> OrchestrationTask:
        """
        从审查请求创建一个编排任务。

        Args:
            tenant_id: 租户ID
            document_content: 原始文档内容
            compliance_domain: 合规领域
            pipeline: 使用的流水线定义（默认使用标准四步流水线）
            priority: 优先级
            extra_context: 额外上下文
        """
        pipeline = pipeline or DEFAULT_PIPELINE

        # 构建任务上下文
        context = {
            "tenant_id": tenant_id,
            "document_content": document_content,
            "compliance_domain": compliance_domain,
            "document_id": extra_context.get("document_id", f"doc_{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}") if extra_context else "",
            "output_path": extra_context.get("output_path", f"output/review_{tenant_id}.docx") if extra_context else "",
            **(extra_context or {}),
        }

        # 从流水线定义构建步骤
        steps = []
        for step_def in pipeline.steps:
            agent_type = AgentType(step_def["agent_type"])
            steps.append(
                TaskStep(
                    agent_type=agent_type,
                    capability=step_def["capability"],
                    input_mapping=step_def["input_mapping"],
                )
            )

        task = OrchestrationTask(
            tenant_id=tenant_id,
            pipeline_name=pipeline.name,
            steps=steps,
            priority=priority,
            context=context,
        )

        self._active_tasks[task.task_id] = task

        # 写审计日志
        logger.info(
            "task_created task_id=%s tenant=%s pipeline=%s steps=%d",
            task.task_id, tenant_id, pipeline.name, len(steps),
        )

        return task

    async def execute_task(self, task_id: str) -> OrchestrationTask:
        """执行一个编排任务（异步）"""
        task = self._active_tasks.get(task_id)
        if not task:
            raise ValueError(f"任务不存在: {task_id}")

        task.status = TaskStatus.RUNNING
        task.updated_at = datetime.now(timezone.utc).isoformat()

        for i, step in enumerate(task.steps):
            task.current_step_index = i
            step.status = TaskStatus.RUNNING
            step.started_at = datetime.now(timezone.utc).isoformat()

            try:
                # 1. 解析输入参数（从前置步骤或上下文取值）
                resolved_input = self._resolve_input(step.input_mapping, task)

                # 2. 查找可用 Agent
                agent = self.registry.find_agent_for_capability(step.capability)
                if not agent:
                    raise RuntimeError(f"没有可用的 Agent 执行能力: {step.capability}")

                # 3. 调用 Agent（通过 MCP 或 HTTP）
                logger.info(
                    "step_executing task_id=%s step=%s agent=%s capability=%s",
                    task_id, step.step_id, agent.agent_id, step.capability,
                )

                result = await self._call_agent(agent, step.capability, resolved_input)
                step.result = result
                step.status = TaskStatus.COMPLETED

                # 将结果写入任务上下文
                task.context[step.step_id] = result

                logger.info("step_completed task_id=%s step=%s", task_id, step.step_id)

            except Exception as e:
                step.status = TaskStatus.FAILED
                step.error = str(e)
                logger.error("step_failed task_id=%s step=%s error=%s", task_id, step.step_id, str(e))

                # 失败处理：如果是必需步骤，终止整个任务
                if self._is_critical_step(step):
                    task.status = TaskStatus.FAILED
                    break
                # 非必需步骤跳过继续

            step.completed_at = datetime.now(timezone.utc).isoformat()

        # 任务完成
        if task.status != TaskStatus.FAILED:
            task.status = TaskStatus.COMPLETED

        task.updated_at = datetime.now(timezone.utc).isoformat()
        self._task_history.append(task)
        self._active_tasks.pop(task_id, None)

        return task

    async def execute_parallel(
        self, task_ids: list[str]
    ) -> list[OrchestrationTask]:
        """并行执行多个任务（多文档同时审查）"""
        tasks = await asyncio.gather(
            *[self.execute_task(tid) for tid in task_ids],
            return_exceptions=True,
        )
        results = []
        for t in tasks:
            if isinstance(t, Exception):
                logger.error("parallel_task_error: %s", str(t))
            else:
                results.append(t)
        return results

    def _resolve_input(self, mapping: dict, task: OrchestrationTask) -> dict:
        """解析输入参数映射，从前置步骤或上下文中取值"""
        resolved = {}
        for key, value_ref in mapping.items():
            if isinstance(value_ref, str) and value_ref.startswith("$."):
                # $.context.compliance_domain → task.context["compliance_domain"]
                # $.steps.pii_desensitize.desensitized_content → task.context["pii_desensitize"]["desensitized_content"]
                path = value_ref[2:].split(".")
                current = task.context
                try:
                    for p in path:
                        if p == "context":
                            continue  # $.context.xxx 等价于 $.xxx
                        current = current[p] if isinstance(current, dict) else getattr(current, p, None)
                    resolved[key] = current
                except (KeyError, TypeError, AttributeError):
                    resolved[key] = None
            else:
                resolved[key] = value_ref
        return resolved

    async def _call_agent(
        self, agent, capability: str, params: dict
    ) -> dict:
        """调用 Agent 执行能力"""
        if not agent.endpoint:
            raise RuntimeError(f"Agent {agent.agent_id} 没有配置 endpoint")

        async with httpx.AsyncClient(timeout=60.0) as client:
            # MCP 协议调用
            mcp_request = {
                "jsonrpc": "2.0",
                "id": f"call_{capability}",
                "method": "tools/call",
                "params": {"name": capability, "arguments": params},
            }

            resp = await client.post(agent.endpoint, json=mcp_request)
            resp.raise_for_status()

            data = resp.json()
            if "error" in data:
                raise RuntimeError(data["error"].get("message", "Agent error"))

            # 解析 MCP 响应中的 content
            result = data.get("result", {})
            content = result.get("content", [])
            if content and isinstance(content, list):
                text_content = content[0].get("text", "{}")
                try:
                    return json.loads(text_content)
                except json.JSONDecodeError:
                    return {"raw": text_content}

            return result

    def _is_critical_step(self, step: TaskStep) -> bool:
        """判断步骤是否为必需（失败则终止任务）"""
        critical_combos = {
            (AgentType.PII_GATEWAY, "desensitize_document"): True,
            (AgentType.COMPLIANCE_JUDGE, "compliance_review"): True,
        }
        return critical_combos.get((step.agent_type, step.capability), False)

    def get_task(self, task_id: str) -> Optional[OrchestrationTask]:
        return self._active_tasks.get(task_id) or next(
            (t for t in self._task_history if t.task_id == task_id), None
        )

    def list_active_tasks(self, tenant_id: Optional[str] = None) -> list[OrchestrationTask]:
        tasks = list(self._active_tasks.values())
        if tenant_id:
            tasks = [t for t in tasks if t.tenant_id == tenant_id]
        return tasks

    def get_task_history(self, tenant_id: Optional[str] = None, limit: int = 20) -> list[OrchestrationTask]:
        tasks = self._task_history[-limit:]
        if tenant_id:
            tasks = [t for t in tasks if t.tenant_id == tenant_id]
        return tasks
