"""
Agent 注册中心 — 中台的服务发现与生命周期管理。

职责:
  1. Agent 注册/注销 — 上线时注册能力，下线时优雅摘除
  2. 心跳检测 — 定时健康检查，自动标记不健康 Agent
  3. 能力查询 — 根据任务需求匹配可用的 Agent
  4. 负载均衡 — 同一类型多个 Agent 实例时做选择
"""

import logging
import threading
import time
from datetime import datetime, timezone
from typing import Optional

from services.agent_orchestrator.models import (
    AgentRegistration,
    AgentStatus,
    AgentType,
    AgentCapability,
)

logger = logging.getLogger(__name__)


class AgentRegistry:
    """Agent 注册中心 — 单例模式"""

    _instance: Optional["AgentRegistry"] = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return
        self._initialized = True

        # agent_id → AgentRegistration
        self._agents: dict[str, AgentRegistration] = {}
        # agent_type → [agent_id, ...]
        self._type_index: dict[AgentType, list[str]] = {}
        # capability_name → [agent_id, ...]
        self._capability_index: dict[str, list[str]] = {}

        # 心跳超时阈值（秒）
        self._heartbeat_timeout = 30

        # 启动后台心跳检查
        self._start_heartbeat_checker()

    # ─── 注册/注销 ──────────────────────────────────────────

    def register(self, agent: AgentRegistration) -> str:
        """注册一个 Agent"""
        agent.status = AgentStatus.ONLINE
        agent.last_heartbeat = datetime.now(timezone.utc).isoformat()
        self._agents[agent.agent_id] = agent

        # 更新类型索引
        if agent.agent_type not in self._type_index:
            self._type_index[agent.agent_type] = []
        if agent.agent_id not in self._type_index[agent.agent_type]:
            self._type_index[agent.agent_type].append(agent.agent_id)

        # 更新能力索引
        for cap in agent.capabilities:
            if cap.name not in self._capability_index:
                self._capability_index[cap.name] = []
            if agent.agent_id not in self._capability_index[cap.name]:
                self._capability_index[cap.name].append(agent.agent_id)

        logger.info(
            "agent_registered agent_id=%s type=%s capabilities=%d",
            agent.agent_id,
            agent.agent_type.value,
            len(agent.capabilities),
        )
        return agent.agent_id

    def deregister(self, agent_id: str) -> bool:
        """注销 Agent"""
        agent = self._agents.pop(agent_id, None)
        if not agent:
            return False

        # 清理索引
        for idx_list in [
            self._type_index.get(agent.agent_type, []),
            *[self._capability_index.get(cap.name, []) for cap in agent.capabilities],
        ]:
            if agent_id in idx_list:
                idx_list.remove(agent_id)

        logger.info("agent_deregistered agent_id=%s", agent_id)
        return True

    def heartbeat(self, agent_id: str) -> bool:
        """Agent 心跳上报"""
        agent = self._agents.get(agent_id)
        if not agent:
            return False
        agent.last_heartbeat = datetime.now(timezone.utc).isoformat()
        if agent.status == AgentStatus.OFFLINE:
            agent.status = AgentStatus.ONLINE
        return True

    # ─── 查询 ──────────────────────────────────────────────

    def get_agent(self, agent_id: str) -> Optional[AgentRegistration]:
        return self._agents.get(agent_id)

    def get_agents_by_type(self, agent_type: AgentType) -> list[AgentRegistration]:
        """获取某一类型的所有在线 Agent"""
        ids = self._type_index.get(agent_type, [])
        return [self._agents[aid] for aid in ids if aid in self._agents and self._agents[aid].status != AgentStatus.OFFLINE]

    def find_agent_for_capability(self, capability_name: str) -> Optional[AgentRegistration]:
        """查找能执行某项能力的 Agent（负载均衡：随机选一个在线的）"""
        ids = self._capability_index.get(capability_name, [])
        online = [
            self._agents[aid]
            for aid in ids
            if aid in self._agents and self._agents[aid].status == AgentStatus.ONLINE
        ]
        if not online:
            return None
        # 简单负载均衡：选能力最多的（减少碎片化）
        return max(online, key=lambda a: len(a.capabilities))

    def list_all(self) -> list[AgentRegistration]:
        return list(self._agents.values())

    def get_registry_status(self) -> dict:
        """获取注册中心整体状态"""
        by_type = {}
        for t in AgentType:
            agents = self.get_agents_by_type(t)
            by_type[t.value] = {
                "total": len(self._type_index.get(t, [])),
                "online": len(agents),
                "agents": [
                    {"id": a.agent_id, "name": a.name, "version": a.version, "capabilities": len(a.capabilities)}
                    for a in agents
                ],
            }

        return {
            "total_agents": len(self._agents),
            "online_agents": sum(1 for a in self._agents.values() if a.status == AgentStatus.ONLINE),
            "by_type": by_type,
            "capabilities": {k: len(v) for k, v in self._capability_index.items()},
        }

    # ─── 心跳检查 ──────────────────────────────────────────

    def _start_heartbeat_checker(self):
        """后台线程：定期检查 Agent 心跳，超时标记离线"""

        def checker():
            while True:
                time.sleep(10)  # 每 10 秒检查一次
                try:
                    now = datetime.now(timezone.utc)
                    for agent in list(self._agents.values()):
                        last_hb = datetime.fromisoformat(agent.last_heartbeat)
                        if (now - last_hb).total_seconds() > self._heartbeat_timeout:
                            if agent.status != AgentStatus.OFFLINE:
                                agent.status = AgentStatus.OFFLINE
                                logger.warning("agent_heartbeat_lost agent_id=%s", agent.agent_id)
                except Exception:
                    pass

        t = threading.Thread(target=checker, daemon=True, name="agent-heartbeat-checker")
        t.start()


# 全局单例
agent_registry = AgentRegistry()
